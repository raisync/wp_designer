<?php
/**
 * Plugin Name: Beaver Builder Theme Modules
 * Description: Theme modules for beaver builder.
 * Version: 1.10.5.1
 * Author: The Beaver Builder Team
 */
define( 'FL_MODULE_THEME_DIR', plugin_dir_path( __FILE__ ) );
define( 'FL_MODULE_THEME_URL', plugins_url( '/', __FILE__ ) );

/**
 * Custom modules
 */
if ( class_exists( 'FLBuilder' ) ) {
	function fl_load_theme_modules() {
		global $foldercategory;
		$foldercategory = 'Theme Modules';
		global $themeDIR;
		$themeDIR = 'theme';

		/*Modify*/
		require_once 'modules/'.$themeDIR.'/rich-text-advanced/rich-text-advanced.php';
		require_once 'modules/'.$themeDIR.'/rich-text-excerpt/rich-text-excerpt.php';
		require_once 'modules/'.$themeDIR.'/sidebar-advanced/sidebar-advanced.php';
		require_once 'modules/'.$themeDIR.'/photo-advanced/photo-advanced.php';

		/*Buttons*/
		require_once 'modules/'.$themeDIR.'/advanced-button/advanced-button.php';
		/*content*/
		require_once 'modules/'.$themeDIR.'/box-link/box-link.php';
		require_once 'modules/'.$themeDIR.'/column-background/column-background.php';
		require_once 'modules/'.$themeDIR.'/counter-bar/counter-bar.php';
		require_once 'modules/'.$themeDIR.'/faq/faq.php';
		require_once 'modules/'.$themeDIR.'/form-box/form-box.php';
		require_once 'modules/'.$themeDIR.'/form-box-newsletter/form-box-newsletter.php';
		require_once 'modules/'.$themeDIR.'/form-newsletter/form-newsletter.php';
		
		require_once 'modules/'.$themeDIR.'/icon-box-toggle/icon-box-toggle.php';
		require_once 'modules/'.$themeDIR.'/skills-bar/skills-bar.php';
		require_once 'modules/'.$themeDIR.'/video-box/video-box.php';
		require_once 'modules/'.$themeDIR.'/map-advanced/map-advanced.php';
		require_once 'modules/'.$themeDIR.'/lists/lists.php';
		require_once 'modules/'.$themeDIR.'/tabs-icon/tabs-icon.php';
		require_once 'modules/'.$themeDIR.'/social-media-icons/social-media-icons.php';
		/*headings*/
		require_once 'modules/'.$themeDIR.'/call-to-action/call-to-action.php';
		require_once 'modules/'.$themeDIR.'/heading-advance/heading-advance.php';
		/*header*/
		require_once 'modules/'.$themeDIR.'/header-sticky/header-sticky.php';
		require_once 'modules/'.$themeDIR.'/header-headroom/header-headroom.php';
		/*grids*/
		require_once 'modules/'.$themeDIR.'/blog/blog.php';
		require_once 'modules/'.$themeDIR.'/blog-category/blog-category.php';
		require_once 'modules/'.$themeDIR.'/portfolio-mixitup/portfolio-mixitup.php';
		require_once 'modules/'.$themeDIR.'/portfolio-gridder/portfolio-gridder.php';
		require_once 'modules/'.$themeDIR.'/video-mixitup/video-mixitup.php';
		require_once 'modules/'.$themeDIR.'/gallery-scattered/gallery-scattered.php';
		require_once 'modules/'.$themeDIR.'/testimonials-posttype/testimonials-posttype.php';
		require_once 'modules/'.$themeDIR.'/teams/teams.php';
		require_once 'modules/'.$themeDIR.'/partners-logo/partners-logo.php';
		require_once 'modules/'.$themeDIR.'/benefits/benefits.php';
		/*separator and effects*/
		require_once 'modules/'.$themeDIR.'/parallax/parallax.php';
		require_once 'modules/'.$themeDIR.'/row-separator/row-separator.php';
		require_once 'modules/'.$themeDIR.'/row-toggle/row-toggle.php';
		/*slider*/
		require_once 'modules/'.$themeDIR.'/slideshow-image/slideshow-image.php';
		require_once 'modules/'.$themeDIR.'/slideshow-content/slideshow-content.php';
		require_once 'modules/'.$themeDIR.'/slider/slider.php';
		require_once 'modules/'.$themeDIR.'/slider-flickity/slider-flickity.php';
		require_once 'modules/'.$themeDIR.'/slider-flickity-thumb/slider-flickity-thumb.php';
		require_once 'modules/'.$themeDIR.'/carousel/carousel.php';
		/*new slider*/
		require_once 'modules/'.$themeDIR.'/slider-toggle/slider-toggle.php';
		require_once 'modules/'.$themeDIR.'/slider-toggle-content/slider-toggle-content.php';
		require_once 'modules/'.$themeDIR.'/slider-form/slider-form.php';
		/*shop*/
		require_once 'modules/'.$themeDIR.'/woocommerce/woocommerce.php';
		require_once 'modules/'.$themeDIR.'/woocommerce-featured/woocommerce-featured.php';
		require_once 'modules/'.$themeDIR.'/woocommerce-latest/woocommerce-latest.php';
		require_once 'modules/'.$themeDIR.'/woocommerce-category/woocommerce-category.php';
	}
	add_action( 'init', 'fl_load_theme_modules' );

	/*Register Global CSS and JS*/
	wp_register_style( 'button-css', FL_MODULE_THEME_URL.'assets/css/button.css' ); 
	wp_enqueue_style( 'fl-builder', FL_MODULE_THEME_URL.'assets/css/fl-builder.css' );
	wp_enqueue_script( 'fl-builder', FL_MODULE_THEME_URL . 'assets/js/fl-builder.js', array( 'jquery' ) );

	/*Custom fieldstype*/
	include_once( FL_MODULE_THEME_DIR . 'field/field_datedropper.php' ); 	/* 'type' => 'datedropper', */
	include_once( FL_MODULE_THEME_DIR . 'field/field_timedropper.php' ); 	/* 'type' => 'timedropper', */
	include_once( FL_MODULE_THEME_DIR . 'field/field_slider.php' ); 	/* 'type' => 'timedropper', */
	include_once( FL_MODULE_THEME_DIR . 'field/field_title.php' ); 	/* 'type' => 'title', */

	/*Custom Posttype*/
	include_once( FL_MODULE_THEME_DIR . 'posttype/posttype_portfolio.php' );
	include_once( FL_MODULE_THEME_DIR . 'posttype/posttype_video.php' );
	include_once( FL_MODULE_THEME_DIR . 'posttype/posttype_services.php' );
	include_once( FL_MODULE_THEME_DIR . 'posttype/posttype_team.php' );
	include_once( FL_MODULE_THEME_DIR . 'posttype/posttype_testimonials.php' );

	/*ext*/
	//if ( FL_BUILDER_LITE === false ) {
	//	require_once( FL_MODULE_THEME_DIR . 'ext/templates/templates.php' );
	//}

	//from WP repo BB clearcache
	class Delete_Cache_Admin_Bar {
		function __construct() {
			add_action( 'admin_bar_menu',			array( $this, 'fl_builder_sub_menu'		) );
			add_action( 'admin_post_purge_cache',	array( $this, 'fl_builder_clear_cache'	) );
		}
		function add_menu( $id, $title, $href = FALSE, $meta = FALSE, $parent = FALSE ) {
			global $wp_admin_bar;
			if ( ! is_super_admin() || ! is_admin_bar_showing() )
				return;
			$wp_admin_bar->add_menu( array(
				'id'		=> $id,
				'parent'	=> $parent,
				'title'		=> $title,
				'href'		=> $href,
				'meta'		=> $meta
			));
		}
		function add_sub_menu( $id, $parent, $title, $href, $meta = FALSE) {
			global $wp_admin_bar;
			if ( ! is_super_admin() || ! is_admin_bar_showing() )
				return;
			$wp_admin_bar->add_menu( array(
				'id'		=> $id,
				'parent'	=> $parent,
				'title'		=> $title,
				'href'		=> $href,
				'meta'		=> $meta
			));
		}
		public function fl_builder_sub_menu() {
			global $post;
			$referer = '&_wp_http_referer=' . urlencode( wp_unslash( $_SERVER['REQUEST_URI'] ) );
			$action  = 'purge_cache';
			if( !is_admin() ) {
				$this->add_sub_menu(
					'fl-builder-delete-url-cache',
					'fl-builder-frontend-edit-link',
					__('Clear Cache - This Page','fl-builder-delete-cache'),
					wp_nonce_url( admin_url( 'admin-post.php?action=' . $action . '&type=post-' . $post->ID . $referer ), $action . '_post-' . $post->ID )
				);
				$this->add_sub_menu(
					'fl-builder-delete-all-cache',
					'fl-builder-frontend-edit-link',
					__('Clear Cache - All Pages','fl-builder-delete-cache'),
					wp_nonce_url( admin_url( 'admin-post.php?action=' . $action . '&type=all' . $referer ), $action . '_all' )
				);
			}
		}
		public function fl_builder_clear_cache() {
			if ( isset( $_GET['type'], $_GET['_wpnonce'] ) ) {
				$_type     = explode( '-', $_GET['type'] );
				$_type     = reset( $_type );
				$_id       = explode( '-', $_GET['type'] );
				$_id       = end( $_id );
				if ( ! wp_verify_nonce( $_GET['_wpnonce'], 'purge_cache_' . $_GET['type'] ) ) {
					wp_nonce_ays( '' );
				}
				switch( $_type ) {
					case 'all':
						FLBuilderModel::delete_asset_cache_for_all_posts();
						break;
					case 'post':
						FLBuilderModel::delete_all_asset_cache( $_id );
						break;
					default:
						wp_nonce_ays( '' );
						break;
				}
				wp_redirect( wp_get_referer() );
				die();
			}
		}
	}
	add_action( "init", "Delete_Cache_Admin_Bar_init" );
	function Delete_Cache_Admin_Bar_init() {
		global $Delete_Cache_Admin_Bar_init;
		if( class_exists('FLBuilder') ) {
			$Delete_Cache_Admin_Bar_init = new Delete_Cache_Admin_Bar();
		}
	}
	
	/*other menu*/
	add_action('admin_bar_menu', 'menu_bar_pagebuilder', 999);
	function menu_bar_pagebuilder() {
		global $wp_admin_bar;
		$website = esc_url( home_url() );
		$menu_pagebuilder_id = 'fl-builder-frontend-edit-link';
		$wp_admin_bar->add_menu(array('parent' => $menu_pagebuilder_id, 'id' => 'fl-builder-frontend-modules', 'title' => 'Modules', 'href' => $website.'/wp-admin/options-general.php?page=fl-builder-settings#modules', 'meta'  => array( 'class' => 'menu-bar-builder-modules' ),));
		$wp_admin_bar->add_menu(array('parent' => $menu_pagebuilder_id, 'id' => 'fl-builder-frontend-posttypes', 'title' => 'Post Type', 'href' => $website.'/wp-admin/options-general.php?page=fl-builder-settings#post-types', 'meta'  => array( 'class' => 'menu-bar-builder-post-types' ),));
		$wp_admin_bar->add_menu(array('parent' => $menu_pagebuilder_id, 'id' => 'fl-builder-frontend-useraccess', 'title' => 'User Access', 'href' => $website.'/wp-admin/options-general.php?page=fl-builder-settings#user-access', 'meta'  => array( 'class' => 'menu-bar-builder-user-access' ),));
		$wp_admin_bar->add_menu(array('parent' => $menu_pagebuilder_id, 'id' => 'fl-builder-frontend-cache', 'title' => 'Tools', 'href' => $website.'/wp-admin/options-general.php?page=fl-builder-settings#tools', 'meta'  => array( 'class' => 'menu-bar-builder-cache' ),));
	}
}