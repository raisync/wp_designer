<?php
/**
 * Custom fields - title
 */
add_action('fl_builder_control_title', 'fl_title_field', 1, 4);
function fl_title_field($name, $value, $field, $settings) {
}
?>