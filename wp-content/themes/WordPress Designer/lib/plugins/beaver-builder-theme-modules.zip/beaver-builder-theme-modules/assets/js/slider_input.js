function outputUpdate(vol) {
	document.querySelector('input:focus + output').value = vol;
}