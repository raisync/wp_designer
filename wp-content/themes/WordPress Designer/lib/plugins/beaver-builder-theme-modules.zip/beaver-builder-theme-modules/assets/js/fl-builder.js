(function($) {
	$(function() {
		if ($('.fl-builder-bar-actions').length ) {
			$('.fl-builder-hover-content-button').remove();
			$('.fl-builder-bar-actions .fl-clear').before('<span class="fl-builder-hover-content-button fl-builder-button"><i class="fa fa-eye"></i> Quick Test</span>');
			$('.fl-builder-hover-content-button').click(function(){
				if ($(this).hasClass('active')) {
					$(this).removeClass('active');
					$('html').removeClass('hover-active');
					$('.fl-builder-add-content-button').click();
				} else {
					$(this).addClass('active');
					$('html').addClass('hover-active');
					$('.fl-builder-panel-close').click();
				}
			});
		}
		if ($('.fl-builder-upgrade-button').length ) {
			$('#fl-builder-blocks-advanced').remove();
		}
	});
})(jQuery);