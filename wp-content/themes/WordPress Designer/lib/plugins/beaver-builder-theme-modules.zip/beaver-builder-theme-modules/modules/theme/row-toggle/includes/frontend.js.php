(function($) {
	$(function() {
		$('html:not(.fl-builder-edit) .fl-node-<?php echo $id; ?> .toggle-row-button').closest('.fl-row').addClass('active-toggle-row');
		$('html:not(.fl-builder-edit) .fl-node-<?php echo $id; ?> .toggle-row-button').closest('.fl-row').next('.fl-row').addClass('active-toggle-row-target');
		$('.fl-builder-bar').on('click', '.fl-builder-hover-content-button', function(){
			if ($(this).hasClass('active')) {
				$('.toggle-row-button').closest('.fl-row').addClass('active-toggle-row');
				$('.toggle-row-button').closest('.fl-row').next('.fl-row').addClass('active-toggle-row-target');
			} else {
				$('.fl-node-<?php echo $id; ?> .toggle-row-button').closest('.fl-row').removeClass('active-toggle-row');
				$('.toggle-row-button').closest('.fl-row').next('.fl-row').removeClass('active-toggle-row-target');
			}
		});
		$('.fl-node-<?php echo $id; ?> .toggle-row-button').on('click', '.togglable', function(){
			if ($(this).parent().hasClass('active-toggle')) {
				$(this).parent().removeClass('active-toggle');
				$(this).parent().closest('.fl-row').next('.fl-row').addClass('active-toggle-row-target');
			} else {
				$(this).parent().addClass('active-toggle');
				$(this).parent().closest('.fl-row').next('.fl-row').removeClass('active-toggle-row-target');
			}
		});
		var $window = $(window);
		$window.resize(function resize() {
			var maxHeight = $('.fl-node-<?php echo $id; ?>').closest('.fl-row').next('.fl-row').children('.fl-row-content-wrap').outerHeight();
			$('.fl-node-<?php echo $id; ?>').closest('.fl-row').next('.fl-row').css('max-height', maxHeight);
		}).trigger('resize');
	});
})(jQuery);