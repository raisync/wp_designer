(function($) {
	$(function() {
		<?php 
			$column = ( $settings->logos_column <> '' ) ? $settings->logos_column : '5';
			$spacing = ( $settings->logos_column_spacing <> '' ) ? $settings->logos_column_spacing : '3';
			$autoplay = ( $settings->autoplay <> '' ) ? $settings->autoplay : 'false';
			$dots = ( $settings->show_dots <> '' ) ? $settings->show_dots : 'false';
			$nav = ( $settings->show_nav <> '' ) ? $settings->show_nav : 'true';
			$delay = $settings->autoplay_delay <> '' ? $settings->autoplay_delay : '3000';
		?>
		var owl = $(".fl-node-<?php echo $id; ?> .owl-carousel");
		function sliderOwl() {
			owl.owlCarousel({
				items: <?php echo $column; ?>,
				slideBy: <?php echo $column; ?>,
				margin: <?php echo $spacing; ?>,
				navText: ['',''],
				autoplay: <?php echo $autoplay; ?>,
				autoplayTimeout: <?php echo $delay ?>,
				autoplayHoverPause: <?php echo $autoplay; ?>,
				<?php for($i = 0; $i < count($settings->items); $i++) : if(!is_object($settings->items[$i])) continue; endfor; 
				if ( $i > $column ) { ?>
					loop: false,
					touchDrag: false,
					dots: false,
					nav: false,
				<?php } else { ?>
					loop: true,
					dots: <?php echo $dots; ?>,
					nav: <?php echo $nav; ?>,
				<?php } ?>
				autoHeight: true,
				animateOut: 'fadeOut',
				<?php if ( $column == 2 ) { ?>
					responsive : {
						0 : {
							items: 1,
							slideBy: 1,
						},
						768 : {
							items: 2,
							slideBy: 2,
						},
						1280 : {
							items: <?php echo $column; ?>,
							slideBy: <?php echo $column; ?>,
						}
					}
				<?php } ?>
				<?php if ( $column == 3 ) { ?>
					responsive : {
						0 : {
							items: 1,
							slideBy: 1,
						},
						481 : {
							items: 3,
							slideBy: 3,
						},
						1280 : {
							items: <?php echo $column; ?>,
							slideBy: <?php echo $column; ?>,
						}
					}
				<?php } ?>
				<?php if ( $column == 4 ) { ?>
					responsive : {
						0 : {
							items: 1,
							slideBy: 1,
						},
						481 : {
							items: 2,
							slideBy: 2,
						},
						768 : {
							items: 3,
							slideBy: 3,
						},
						1280 : {
							items: <?php echo $column; ?>,
							slideBy: <?php echo $column; ?>,
						}
					}
				<?php } ?>
				<?php if ( $column == 5 ) { ?>
					responsive : {
						0 : {
							items: 2,
							slideBy: 2,
						},
						481 : {
							items: 3,
							slideBy: 3,
						},
						768 : {
							items: 4,
							slideBy: 4,
						},
						1280 : {
							items: <?php echo $column; ?>,
							slideBy: <?php echo $column; ?>,
						}
					}
				<?php } ?>
				<?php if ( $column >= 6 ) { ?>
					responsive : {
						0 : {
							items: 2,
							slideBy: 2,
						},
						481 : {
							items: 3,
							slideBy: 3,
						},
						767 : {
							items: 4,
							slideBy: 4,
						},
						1024 : {
							items: 5,
							slideBy: 5,
						},
						1280 : {
							items: <?php echo $column; ?>,
							slideBy: <?php echo $column; ?>,
						}
					}
				<?php } ?>
			});
		}
		sliderOwl();

		$('body').on('click','.fl-field-responsive-toggle', function(){
			owl.trigger('destroy.owl.carousel');
			owl.html(owl.find('.owl-stage-outer').html()).removeClass('owl-loaded');
			setTimeout(function() {
				sliderOwl();
			}, 300);
		});

		<?php if ( $autoplay === 'true' ) { ?>
			$.fn.visible = function(partial) {		
				var $t            = $(this),
					$w            = $(window),
					viewTop       = $w.scrollTop(),
					viewBottom    = viewTop + $w.height(),
					_top          = $t.offset().top,
					_bottom       = _top + $t.height(),
					compareTop    = partial === true ? _bottom : _top,
					compareBottom = partial === true ? _top : _bottom;		
				return ((compareBottom <= viewBottom) && (compareTop >= viewTop));
			};
			$(window).on("load scroll resize", function(){
				if (owl.visible(true)) {
					owl.trigger('play.owl.autoplay');
				} else {
					owl.trigger('stop.owl.autoplay');
				}
			});
			$(window).on("load scroll resize", function(){
				if (owl.visible(true)) {
					owl.trigger('play.owl.autoplay');
				} else {
					owl.trigger('stop.owl.autoplay');
				}
			});
		<?php } ?>
		$(window).on("load", function(){
			owl.trigger('refresh.owl.carousel');
		});
	});
})(jQuery);