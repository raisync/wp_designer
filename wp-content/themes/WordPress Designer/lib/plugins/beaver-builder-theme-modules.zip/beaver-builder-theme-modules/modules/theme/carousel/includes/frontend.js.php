(function($) {
	$(function() {
		<?php $grid = ( $settings->grid <> '' ) ? $settings->grid : '4'; ?>
		<?php $grid_tablet_landscape = ( $settings->grid_tablet_landscape <> '' ) ? $settings->grid_tablet_landscape : '4'; ?>
		<?php $grid_tablet_portrait = ( $settings->grid_tablet_portrait <> '' ) ? $settings->grid_tablet_portrait : '3'; ?>
		<?php $grid_mobile_landscape = ( $settings->grid_mobile_landscape <> '' ) ? $settings->grid_mobile_landscape : '2'; ?>
		<?php $grid_mobile_portrait = ( $settings->grid_mobile_portrait <> '' ) ? $settings->grid_mobile_portrait : '1'; ?>
		<?php $spacing = ( $settings->spacing <> '' ) ? $settings->spacing : '30'; ?>
		<?php $autoplay = ( $settings->autoplay <> '' ) ? $settings->autoplay : 'false'; ?>
		<?php $delay = $settings->autoplay_delay <> '' ? $settings->autoplay_delay : '6000'; ?>
		<?php $speed = $settings->autoplay_speed <> '' ? $settings->autoplay_speed : '300'; ?>
		var owl = $(".fl-node-<?php echo $id; ?> .owl-carousel");
		owl.owlCarousel({
			margin: <?php echo $spacing; ?>,
			dots: <?php echo $settings->show_dots; ?>,
			nav: <?php echo $settings->show_nav; ?>,
			navText: ['',''],
			autoplay: <?php echo $autoplay; ?>,
			autoplayHoverPause: <?php echo $autoplay; ?>,
			autoplayTimeout: <?php echo $delay ?>,
			autoplaySpeed: <?php echo $speed ?>,
			dragEndSpeed: <?php echo $speed ?>,
			dotsSpeed: <?php echo $speed ?>,
			navSpeed: <?php echo $speed ?>,
			fluidSpeed: <?php echo $speed ?>,
			smartSpeed: <?php echo $speed ?>,
			<?php for($i = 0; $i < count($settings->items); $i++) : if(!is_object($settings->items[$i])) continue; endfor; 
			if ( $i > 1 && $settings->loop == 'true' ) { ?>
				loop: true,
			<?php } else if ( $settings->loop == 'true' ) { ?>
				loop: true,
			<?php } else { ?>
				loop: false,
				rewind: false,
			<?php } ?>
			autoHeight: true,
			responsive : {
				0 : {
					items: <?php echo $grid_mobile_portrait; ?>,
					slideBy: <?php echo $grid_mobile_portrait; ?>,
				},
				568 : {
					items: <?php echo $grid_mobile_landscape; ?>,
					slideBy: <?php echo $grid_mobile_landscape; ?>,
				},
				768 : {
					items: <?php echo $grid_tablet_portrait; ?>,
					slideBy: <?php echo $grid_tablet_portrait; ?>,
				},
				800 : {
					items: <?php echo $grid_tablet_landscape; ?>,
					slideBy: <?php echo $grid_tablet_landscape; ?>,
				},
				1080 : {
					items: <?php echo $grid; ?>,
					slideBy: <?php echo $grid; ?>,
				},
			}
		});
		
		<?php if ( $settings->show_dots === 'true' ) { ?>
			var $dotsH = $('.fl-node-<?php echo $id; ?> .owl-carousel .owl-dots').outerHeight();
			$('.fl-node-<?php echo $id; ?> .owl-carousel .owl-nav').css('margin-top', '-'+$dotsH/2+'px');
		<?php } ?>

		<?php if ( $autoplay === 'true' ) { ?>
			$.fn.visible = function(partial) {		
				var $t            = $(this),
					$w            = $(window),
					viewTop       = $w.scrollTop(),
					viewBottom    = viewTop + $w.height(),
					_top          = $t.offset().top,
					_bottom       = _top + $t.height(),
					compareTop    = partial === true ? _bottom : _top,
					compareBottom = partial === true ? _top : _bottom;		
				return ((compareBottom <= viewBottom) && (compareTop >= viewTop));
			};
			$(window).on("load scroll resize", function(){
				if (owl.visible(true)) {
					owl.trigger('play.owl.autoplay')
				} else {
					owl.trigger('stop.owl.autoplay')
				}
			});
		<?php } ?>
	});
	
})(jQuery);