<?php if ( !empty($settings->row_toggle_color) ) { ?>
	.fl-node-<?php echo $id; ?> .toggle-row-button {
		color: #<?php echo $settings->row_toggle_color; ?>;
	}
<?php } ?>
<?php if ( $settings->row_toggle_size <> '' ) { ?>
	.fl-node-<?php echo $id; ?> .toggle-row-title {
		font-size: <?php echo $settings->row_toggle_size; ?>px;
	}
<?php } ?>
<?php 
// MEDIUM - GLOBAL SETTING
$global_settings = FLBuilderModel::get_global_settings(); ?>
@media only screen and ( max-width: <?php echo $global_settings->medium_breakpoint; ?>px ) {
	<?php if ( !empty($settings->row_toggle_color_medium) ) { ?>
		.fl-node-<?php echo $id; ?> .toggle-row-button {
			color: #<?php echo $settings->row_toggle_color_medium; ?>;
		}
	<?php } ?>
	<?php if ( $settings->row_toggle_size_medium <> '' ) { ?>
		.fl-node-<?php echo $id; ?> .toggle-row-title {
			font-size: <?php echo $settings->row_toggle_size_medium; ?>px;
		}
	<?php } ?>
}
@media only screen and ( max-width: <?php echo $global_settings->responsive_breakpoint; ?>px ) {
	<?php if ( !empty($settings->row_toggle_color_responsive) ) { ?>
		.fl-node-<?php echo $id; ?> .toggle-row-button {
			color: #<?php echo $settings->row_toggle_color_responsive; ?>;
		}
	<?php } ?>
	<?php if ( $settings->row_toggle_size_responsive <> '' ) { ?>
		.fl-node-<?php echo $id; ?> .toggle-row-title {
			font-size: <?php echo $settings->row_toggle_size_responsive; ?>px;
		}
	<?php } ?>
}