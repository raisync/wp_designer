(function($) {
	$(function() {
		<?php
			$address = $settings->address;
			$latLong = getLatLong($address);
			$latitude = $latLong['latitude']?$latLong['latitude']:'';
			$longitude = $latLong['longitude']?$latLong['longitude']:'';
			$markerDefault = $module->url.'/includes/marker.png';
			$marker = ($settings->marker <> '') ? $settings->marker_src : $markerDefault;
			$zoom = $settings->zoom <> '' ? $settings->zoom : '15';
			$map_color = '['.$settings->map_color.']';
		?>
		function initialize() {
			var locations = [
				["<?php echo $address; ?>", <?php echo $latitude; ?>, <?php echo $longitude; ?>, '<?php echo $marker; ?>'],
				<?php
					for($i = 0; $i < count($settings->addresses); $i++) : if(!is_object($settings->addresses[$i])) continue;
						if ( !empty($settings->addresses[$i]->addresses_location) ) {
							$addresses = $settings->addresses[$i]->addresses_location;
							$latLongNew = getLatLong($addresses);
							$latitudeNew = $latLongNew['latitude']?$latLongNew['latitude']:'';
							$longitudeNew = $latLongNew['longitude']?$latLongNew['longitude']:'';
							$markerNew = ( $settings->addresses[$i]->addresses_marker <> '') ? $settings->addresses[$i]->addresses_marker_src : $markerDefault;
							echo '["'.$addresses.'", '.$latitudeNew.', '.$longitudeNew.', "'.$markerNew.'"],';
						}
					endfor;
				?>
			];
			var map = new google.maps.Map(document.getElementById('map_<?php echo $id; ?>'), {
				center: new google.maps.LatLng(<?php echo $latitude; ?>, <?php echo $longitude; ?>),
				zoom: <?php echo $zoom; ?>,
				mapTypeId: google.maps.MapTypeId.ROADMAP,
				scrollwheel: false,
				<?php if ($settings->map_color <> '') { ?>
				styles: <?php echo $map_color;?>
				<?php } ?>
			});
			var infowindow = new google.maps.InfoWindow(),
				marker, i;
			for (i = 0; i < locations.length; i++ ) {  
				marker = new google.maps.Marker({
					position: new google.maps.LatLng(locations[i][1], locations[i][2]),
					map: map,
					optimized:false,
					icon: locations[i][3],
					<?php if ($settings->marker_animation == 'yes') { ?>
					animation: google.maps.Animation.BOUNCE,
					<?php } else { ?>
					animation: google.maps.Animation.DROP,
					<?php } ?>
				});

				google.maps.event.addListener(marker, 'click', (function(marker, i) {
					return function() {
					  infowindow.setContent(locations[i][0]);
					  infowindow.open(map, marker);
					}
				})(marker, i));
			}
		}

		$( '.fl-builder-content' ).on( 'fl-builder.preview-rendered', initialize() );
		google.maps.event.addDomListener(window, "resize", function() {
			var center = map.getCenter();
			google.maps.event.trigger(map, "resize");
			map.setCenter(center);
		});
	});
})(jQuery);