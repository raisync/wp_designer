<?php

/**
 * @class sliderToggleModule
 */
class sliderToggleModule extends FLBuilderModule {

	/** 
	 * @method __construct
	 */  
	public function __construct()
	{
		global $foldercategory;
		parent::__construct(array(
			'name'          	=> __('Slider Toggle (Page Template - Product)', 'fl-builder'),
			'description'   	=> __('Fullscreen Toggle Page Template Content.', 'fl-builder'),
			'category'      	=> __($foldercategory, 'fl-builder'),
			'partial_refresh'	=> true
		));
		// Register and enqueue your own.
		$this->add_css( 'owl-carousel', FL_MODULE_THEME_URL . 'assets/owlcarousel/owl.carousel.css' );
		$this->add_css( 'owl-carousel-theme', FL_MODULE_THEME_URL . 'assets/owlcarousel/owl.theme.default.min.css' );
		$this->add_js( 'owl-carousel', FL_MODULE_THEME_URL . 'assets/owlcarousel/owl.carousel.min.js', array(), '', true );
		$this->add_css( 'smooth-scrollbar', $this->url . 'js/smooth-scrollbar/smooth-scrollbar.css' );
		$this->add_js( 'smooth-scrollbar', $this->url . 'js/smooth-scrollbar/smooth-scrollbar.js', array(), '', true );
	}
	/**
	 * @method get_classname
	 */
	public function get_classname()
	{
		$classname = 'slider-toggle';
		return $classname;
	}
}

/*Module Image Size*/
add_image_size( 'slider-toggle-image', 1600 , 920, true );
add_image_size( 'slider-toggle-thumb', 288 , 161, true );
add_image_size( 'slider-toggle-content-images', 462 , 464, true );

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('sliderToggleModule', array(
	'slides'         => array(
		'title'         => __('Slides', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
					'items'         => array(
						'type'          => 'form',
						'label'         => __('Slide', 'fl-builder'),
						'form'          => 'slider_form', // ID from registered form below
						'preview_text'  => 'slider_title', // Name of a field to use for the preview text
						'multiple'      => true
					),
				)
			)
		)
	),
	'toggles_content'         => array(
		'title'         => __('Toggles Content', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
					'toggles_item'         => array(
						'type'          => 'form',
						'label'         => __('Slide', 'fl-builder'),
						'form'          => 'toggles_item_form', // ID from registered form below
						'preview_text'  => 'toggles_item_page', // Name of a field to use for the preview text
						'multiple'      => true
					),
				)
			)
		)
	),
	'setting'        => array(
		'title'         => __('Settings', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
					'autoplay'        => array(
						'type'          => 'select',
						'label'         => __('Autoplay', 'fl-builder'),
						'default'       => 'true',
						'options'       => array(
							'true'    => __('Yes', 'fl-builder'),
							'false'      => __('No', 'fl-builder'),
						),
						'toggle'        => array(
							'true'        => array(
								'fields'        => array('autoplay_delay', 'autoplay_speed')
							),
						),
					),
					'autoplay_delay'        => array(
						'type'          => 'unit',
						'label'         => __('Autoplay Delay', 'fl-builder'),
						'placeholder'       => '7000',
						'description'       => 'Millisecond',
					),
					'autoplay_speed'        => array(
						'type'          => 'unit',
						'label'         => __('Autoplay Speed', 'fl-builder'),
						'placeholder'       => '1500',
						'description'       => 'Millisecond',
					),
					'loop_animation'        => array(
						'type'          => 'select',
						'label'         => __('Loop Animation', 'fl-builder'),
						'default'       => 'fade',
						'options'       => array(
							'fade'    => __('Fade', 'fl-builder'),
							'slide'      => __('Slide', 'fl-builder'),
						),
						'toggle'        => array(
							'slide'        => array(
								'fields'        => array('autoplay_speed')
							),
						),
					),
				)
			),
			'color'       => array(
				'title'         => 'Color',
				'fields'        => array(  
					'slider_bg_color'       => array(
						'type'          => 'color',
						'label'         => 'Background Color',
						'show_reset'    => true,
						'preview'       => array(
							'type'          => 'css',
							'selector'      => '.slider',
							'property'      => 'background-color',
						)
					),  
				)
			),
			'padding'       => array(
				'title'         => 'Padding',
				'fields'        => array(       
					'padding_top'       => array(
						'type'          => 'unit',
						'label'         => 'Top',
						'placeholder'         => '110',
						'maxlength'     => '3',
						'size'          => '4',
						'description'   => 'px',
						'preview'       => array(
							'type'          => 'css',
							'selector'      => '.slider-info',
							'property'      => 'padding-top',
							'unit'          => 'px'
						),
						'responsive'  => array(
							'placeholder' => array(
								'default'    => ( isset( $global_settings->padding_top ) ) ? $global_settings->padding_top : '110',
								'medium'     => ( isset( $global_settings->padding_top_medium ) ) ? $global_settings->padding_top_medium : '60',
								'responsive' => ( isset( $global_settings->padding_top_responsive ) ) ? $global_settings->padding_top_responsive : '',
							)
						),
					),    
					'padding_bottom'       => array(
						'type'          => 'unit',
						'label'         => 'Bottom',
						'placeholder'         => '70',
						'maxlength'     => '3',
						'size'          => '4',
						'description'   => 'px',
						'preview'       => array(
							'type'          => 'css',
							'selector'      => '.slider-info',
							'property'      => 'padding-bottom',
							'unit'          => 'px'
						),
						'responsive'  => array(
							'placeholder' => array(
								'default'    => ( isset( $global_settings->padding_bottom ) ) ? $global_settings->padding_bottom : '70',
								'medium'     => ( isset( $global_settings->padding_bottom_medium ) ) ? $global_settings->padding_bottom_medium : '60',
								'responsive' => ( isset( $global_settings->padding_bottom_responsive ) ) ? $global_settings->padding_bottom_responsive : '',
							)
						),
					),    
					'padding_left'       => array(
						'type'          => 'unit',
						'label'         => 'Left',
						'placeholder'         => '80',
						'maxlength'     => '3',
						'size'          => '4',
						'description'   => 'px',
						'preview'       => array(
							'type'          => 'css',
							'selector'      => '.slider-info',
							'property'      => 'padding-left',
							'unit'          => 'px'
						),
						'responsive'  => array(
							'placeholder' => array(
								'default'    => ( isset( $global_settings->padding_left ) ) ? $global_settings->padding_left : '80',
								'medium'     => ( isset( $global_settings->padding_left_medium ) ) ? $global_settings->padding_left_medium : '20',
								'responsive' => ( isset( $global_settings->padding_left_responsive ) ) ? $global_settings->padding_left_responsive : '',
							)
						),
					),    
					'padding_right'       => array(
						'type'          => 'unit',
						'label'         => 'Right',
						'placeholder'         => '80',
						'maxlength'     => '3',
						'size'          => '4',
						'description'   => 'px',
						'preview'       => array(
							'type'          => 'css',
							'selector'      => '.slider-info',
							'property'      => 'padding-right',
							'unit'          => 'px'
						),
						'responsive'  => array(
							'placeholder' => array(
								'default'    => ( isset( $global_settings->padding_right ) ) ? $global_settings->padding_right : '80',
								'medium'     => ( isset( $global_settings->padding_right_medium ) ) ? $global_settings->padding_right_medium : '20',
								'responsive' => ( isset( $global_settings->padding_right_responsive ) ) ? $global_settings->padding_right_responsive : '',
							)
						),
					),
				)
			),
		)
	)
));

/**
 * Register a settings form to use in the "form" field type above.
 */
FLBuilder::register_settings_form('slider_form', array(
	'title' => __('Slide', 'fl-builder'),
	'tabs'  => array(
		'slide'      => array(
			'title'         => __('Slide Info', 'fl-builder'),
			'sections'      => array(
				'info_bg'       => array(
					'title'         => __('Background', 'fl-builder'),
					'fields'        => array(
						'slider_bg_image'       => array(
							'type'          => 'photo',
							'label'         => 'Background Image',
							'show_remove' 	=> true,
						),
					),
				),
				'info_text'       => array(
					'title'         => __('Text', 'fl-builder'),
					'fields'        => array(
						'slider_title'       => array(
							'type'          => 'text',
							'label'         => 'Title',
							'default'   => __('Featured <strong>Site</strong><span>name</span> Headings', 'fl-builder'),
							'placeholder'   => __('Featured <strong>Site</strong><span>name</span> Headings', 'fl-builder'),
						),
						'slider_text'       => array(
							'type'          => 'textarea',
							'label'         => 'Text',
							'default'   => __('Pellentesque eget fringilla turtpis. Integer sed felis id.', 'fl-builder'),
						),
					),
				),
			)
		),
		'slide_setting'      => array(
			'title'         => __('Slide Setting', 'fl-builder'),
			'sections'      => array(
				'slide_aligment'       => array(
					'title'         => __('Slide Style', 'fl-builder'),
					'fields'        => array(
						'slider_style'        => array(
							'type'          => 'select',
							'label'         => __('Slide Aligment', 'fl-builder'),
							'default'       => 'left',
							'options'       => array(
								'left'    	=> __('Left', 'fl-builder'),
								'center'    => __('Center', 'fl-builder'),
								'right'     => __('Right', 'fl-builder'),
							),
						),
						'slider_title_max_width'       => array(
							'type'          => 'unit',
							'label'         => 'Title Max Width',
							'description'   => 'px',
							'responsive'  => array(
								'placeholder' => array(
									'default'    => ( isset( $global_settings->slider_title_max_width ) ) ? $global_settings->slider_title_max_width : '700',
									'medium'     => ( isset( $global_settings->slider_title_max_width_medium ) ) ? $global_settings->slider_title_max_width_medium : '',
									'responsive' => ( isset( $global_settings->slider_title_max_width_responsive ) ) ? $global_settings->slider_title_max_width_responsive : '',
								)
							),
						),
						'slider_text_max_width'       => array(
							'type'          => 'unit',
							'label'         => 'Text Max Width',
							'description'   => 'px',
							'responsive'  => array(
								'placeholder' => array(
									'default'    => ( isset( $global_settings->slider_text_max_width ) ) ? $global_settings->slider_text_max_width : '500',
									'medium'     => ( isset( $global_settings->slider_text_max_width_medium ) ) ? $global_settings->slider_text_max_width_medium : '',
									'responsive' => ( isset( $global_settings->slider_text_max_width_responsive ) ) ? $global_settings->slider_text_max_width_responsive : '',
								)
							),
						),
					)
				),
			)
		),
	)
));


// Get Category http://stackoverflow.com/questions/21009516/get-categories-from-wordpress-woocommerce
$taxonomy     = 'testimonial_category';
$orderby      = 'name';  
$show_count   = 0;      // 1 for yes, 0 for no
$pad_counts   = 0;      // 1 for yes, 0 for no
$hierarchical = 1;      // 1 for yes, 0 for no  
$title        = '';  
$empty        = 0;
$args = array(
	 'taxonomy'     => $taxonomy,
	 'orderby'      => $orderby,
	 'show_count'   => $show_count,
	 'pad_counts'   => $pad_counts,
	 'hierarchical' => $hierarchical,
	 'title_li'     => $title,
	 'hide_empty'   => $empty
);
$all_categories = get_categories( $args );
$posttypeCategories = array();
foreach ($all_categories as $cat) {
	if($cat->category_parent == 0) {
		$category_id = $cat->term_id;       
		$posttypeCategories[$cat->slug] = ucfirst($cat->name);
			//Child Category
			$args2 = array(
					'taxonomy'     => $taxonomy,
					'child_of'     => 0,
					'parent'       => $category_id,
					'orderby'      => $orderby,
					'show_count'   => $show_count,
					'pad_counts'   => $pad_counts,
					'hierarchical' => $hierarchical,
					'title_li'     => $title,
					'hide_empty'   => $empty
			);
			$sub_cats = get_categories( $args2 );
			if($sub_cats) {
				foreach($sub_cats as $sub_category) {
					$posttypeCategories[$sub_category->slug] = '-- '.ucfirst($sub_category->name);
				}   
			}
	}       
}

/*page-template*/
$args = array(
    'post_type' => 'page',
	'meta_key'   => '_wp_page_template',
    'meta_value' => 'page-product.php'
);
$the_pages = get_posts( $args );
$productList = array();
foreach ($the_pages as $page) {
	$productList[$page->ID] = $page->post_title;
}
/**
 * Register a settings form to use in the "form" field type above.
 */
FLBuilder::register_settings_form('toggles_item_form', array(
	'title' => __('Slide', 'fl-builder'),
	'tabs'  => array(
		'slide'      => array(
			'title'         => __('Toggles Content', 'fl-builder'),
			'sections'      => array(
				'toggles_bg'       => array(
					'title'         => __('Content', 'fl-builder'),
					'fields'        => array(
						'toggles_item_page'         => array(
							'type'          => 'select',
							'label'         => __('Select Toggle Content Page', 'fl-builder'),
							'options'       => $productList,
							'help'   => 'Create a page using (Page Template Product) and add the value for "Excerpt and Data"',
						),
						'toggles_item_image'       => array(
							'type'          => 'photo',
							'label'         => 'Image',
							'show_remove' 	=> true,
							'description'   => __('Custom Image for Feature Image', 'fl-builder'),
						),
						'toggles_item_title'       => array(
							'type'          => 'text',
							'label'         => 'Title',
							'default'   => __('', 'fl-builder'),
							'placeholder'   => __('Custom Title for Page Title', 'fl-builder'),
						),
						'toggles_item_table_title'       => array(
							'type'          => 'text',
							'label'         => 'Table Title',
							'default'   	=> __('', 'fl-builder'),
							'placeholder'   => __('Custom Title for Data From The Past 30 Days', 'fl-builder'),
						),
						
						'toggles_item_table_col_1_title'       => array(
							'type'          => 'text',
							'label'         => 'Table Column 1 Title',
							'default'   	=> __('', 'fl-builder'),
							'placeholder'   => __('Custom Title for Drinks Poured', 'fl-builder'),
						),
						
						'toggles_item_table_col_2_title'       => array(
							'type'          => 'text',
							'label'         => 'Table Column 2 Title',
							'default'   	=> __('', 'fl-builder'),
							'placeholder'   => __('Custom Title for Total Revenue', 'fl-builder'),
						),
						
						'toggles_item_table_col_3_title'       => array(
							'type'          => 'text',
							'label'         => 'Table Column 3 Title',
							'default'   	=> __('', 'fl-builder'),
							'placeholder'   => __('Custom Title for Active Taps', 'fl-builder'),
						),
						
						'toggles_item_read_more'       => array(
							'type'          => 'text',
							'label'         => 'Read More Text',
							'default'   	=> __('', 'fl-builder'),
							'placeholder'   => __('Custom Read More Text', 'fl-builder'),
						),
					),
				),
				'toggles_testimonial'       => array(
					'title'         => __('Testimonial', 'fl-builder'),
					'fields'        => array(
						'testimonial_categories'         => array(
							'type'          => 'select',
							'label'         => __('Select Testimonial Category', 'fl-builder'),
							'options'       => $posttypeCategories,
							'multi-select'  => true
						),
						'testimonial_order'         => array(
							'type'          => 'select',
							'label'         => __('Testimonial Order Sorting', 'fl-builder'),
							'default'       => 'ASC',
							'options'       => array(
								'DESC'    		=> __('DESCENDING', 'fl-builder'),
								'ASC'    		=> __('ASCENDING', 'fl-builder'),
							)
						),
						'testimonial_orderby'         => array(
							'type'          => 'select',
							'label'         => __('Testimonial Order By', 'fl-builder'),
							'default'       => 'date',
							'options'       => array(
								'none'    		=> __('none', 'fl-builder'),
								'ID'    		=> __('ID', 'fl-builder'),
								'title'    		=> __('title', 'fl-builder'),
								'name'    		=> __('name', 'fl-builder'),
								'date'    		=> __('date', 'fl-builder'),
								'modified'    	=> __('modified', 'fl-builder'),
								'rand'    		=> __('rand', 'fl-builder'),
								'menu_order'    		=> __('menu_order', 'fl-builder'),
								''    		=> __('', 'fl-builder'),
							),
						),
					),
				),
			)
		),
	)
));