<?php global $wp_embed;
$output = '<div class="'.$module->get_classname().$settings->parallax_blur_overlay.'">';
	for($i = 0; $i < count($settings->items); $i++) : if(!is_object($settings->items[$i])) continue;
		if ( $settings->items[$i]->parallax_reverse == 'yes' ) {
			$to = ($settings->items[$i]->parallax_from <> '') ? $settings->items[$i]->parallax_from : '0';
			$from = ($settings->items[$i]->parallax_to <> '') ? $settings->items[$i]->parallax_to : (($i+1)*100);
		} else {
			$from = ($settings->items[$i]->parallax_from <> '') ? $settings->items[$i]->parallax_from : '0';
			$to = ($settings->items[$i]->parallax_to <> '') ? $settings->items[$i]->parallax_to : (($i+1)*100);
		}
		if ( $settings->items[$i]->parallax_reverse_horizontal == 'yes' ) {
			$to_horizontal = ( $settings->items[$i]->parallax_from_horizontal <> '' ) ? $settings->items[$i]->parallax_from_horizontal : '0';
			$from_horizontal = ( $settings->items[$i]->parallax_to_horizontal <> '' ) ? $settings->items[$i]->parallax_to_horizontal : '0';
		} else {
			$from_horizontal = ( $settings->items[$i]->parallax_from_horizontal <> '' ) ? $settings->items[$i]->parallax_from_horizontal : '0';
			$to_horizontal = ( $settings->items[$i]->parallax_to_horizontal <> '' ) ? $settings->items[$i]->parallax_to_horizontal : '0';
		}
		if ( $settings->items[$i]->parallax_reverse_vertical == 'yes' ) {
			$to_vertical = ( $settings->items[$i]->parallax_from_vertical <> '' ) ? $settings->items[$i]->parallax_from_vertical : '0';
			$from_vertical = ( $settings->items[$i]->parallax_to_vertical <> '' ) ? $settings->items[$i]->parallax_to_vertical : '0';
		} else {
			$from_vertical = ( $settings->items[$i]->parallax_from_vertical <> '' ) ? $settings->items[$i]->parallax_from_vertical : '0';
			$to_vertical = ( $settings->items[$i]->parallax_to_vertical <> '' ) ? $settings->items[$i]->parallax_to_vertical : '0';
		}
		if ( $settings->items[$i]->parallax_start == 'center' ) {
			$data_position_start = 'data-center-center';
		} else {
			$data_position_start = 'data-bottom-top';
		}

		if ( $settings->items[$i]->parallax_end == 'center' ) {
			$data_position_end = 'data-center-center';
		} else {
			$data_position_end = 'data-top-bottom';
		}

		$output .= '<div style="background-image: url('.$settings->items[$i]->parallax_img_src.'); z-index:'.($i+1).';" class="parallax-image parallax-'.($i+1).'" 
			'.$data_position_start.'="background-position: 50% '.$from.'%; transform: translateX('.$from_horizontal.'%) translateY('.$from_vertical.'%);" 
			'.$data_position_end.'="background-position: 50% '.$to.'%; transform: translateX('.$to_horizontal.'%) translateY('.$to_vertical.'%);"
		></div>';
	endfor;
$output .= '</div>';
echo $output;
?>