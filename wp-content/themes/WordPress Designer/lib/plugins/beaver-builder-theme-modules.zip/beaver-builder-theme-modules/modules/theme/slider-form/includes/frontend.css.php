<?php if ( !empty($settings->slider_bg_color) || $settings->padding_top <> '' || $settings->padding_bottom <> '' || $settings->padding_left <> '' || $settings->padding_right <> '' ) { ?>
	.fl-node-<?php echo $id; ?> .slider-form {
		<?php if ( !empty($settings->slider_bg_color) ) { ?>background-color: #<?php echo $settings->slider_bg_color; ?>;<?php } ?>
		<?php if ( $settings->padding_top <> '' ){ ?>padding-top: <?php echo $settings->padding_top; ?>px;<?php } ?>
		<?php if ( $settings->padding_bottom <> '' ) { ?>padding-bottom: <?php echo $settings->padding_bottom; ?>px;<?php } ?>
		<?php if ( $settings->padding_left <> '' ) { ?>padding-left: <?php echo $settings->padding_left; ?>px;<?php } ?>
		<?php if ( $settings->padding_right <> '' ) { ?>padding-right: <?php echo $settings->padding_right; ?>px;<?php } ?>
	}
<?php } ?>

<?php for($i = 0; $i < count($settings->items); $i++) : if(!is_object($settings->items[$i])) continue; ?>
	<?php if ( !empty($settings->items[$i]->slider_bg_image) ) {?>
		.fl-node-<?php echo $id; ?> .slide-<?php echo ($i+1); ?>::before{
			<?php if ( !empty($settings->items[$i]->slider_bg_image) ) { ?>
				 background-image: url(<?php echo $settings->items[$i]->slider_bg_image_src; ?>);
			<?php } ?>
		}
	<?php } ?>
	<?php if ( $settings->items[$i]->slider_title_size <> '' || !empty($settings->items[$i]->slider_title_color) || $settings->items[$i]->slider_title_max_width <> '' ) {?>
		.fl-node-<?php echo $id; ?> .slide-<?php echo ($i+1); ?> .slider-title{
			<?php if ( !empty($settings->items[$i]->slider_title_color) ) { ?>
				color: #<?php echo $settings->items[$i]->slider_title_color; ?>;
			<?php } ?>
			<?php if ( $settings->items[$i]->slider_title_size <> '' ) { ?>
				font-size: <?php echo $settings->items[$i]->slider_title_size; ?>px;
			<?php } ?>
			<?php if ( !empty($settings->items[$i]->slider_title_max_width) ) { ?>
				max-width: <?php echo $settings->items[$i]->slider_title_max_width; ?>px;
			<?php } ?>
		}
	<?php } ?>
	<?php if ( $settings->items[$i]->slider_text_size <> '' || !empty($settings->items[$i]->slider_text_color) || $settings->items[$i]->slider_text_max_width <> '' ) {?>
		.fl-node-<?php echo $id; ?> .slide-<?php echo ($i+1); ?> .slider-text{
			<?php if ( $settings->items[$i]->slider_text_size <> '' ) { ?>
				font-size: <?php echo $settings->items[$i]->slider_text_size; ?>px;
			<?php } ?>
			<?php if ( !empty($settings->items[$i]->slider_text_color) ) { ?>
				color: #<?php echo $settings->items[$i]->slider_text_color; ?>;
			<?php } ?>
			<?php if ( !empty($settings->items[$i]->slider_text_max_width) ) { ?>
				max-width: <?php echo $settings->items[$i]->slider_text_max_width; ?>px;
			<?php } ?>
		}
	<?php } ?>
<?php endfor; ?>



<?php 
$global_settings = FLBuilderModel::get_global_settings(); ?>
@media only screen and ( max-width: <?php echo $global_settings->medium_breakpoint; ?>px ) {
	<?php for($i = 0; $i < count($settings->items); $i++) : if(!is_object($settings->items[$i])) continue; ?>
		<?php if ( $settings->items[$i]->slider_title_size_medium <> '' || $settings->items[$i]->slider_title_size_medium <> '' ) { ?>
			.fl-node-<?php echo $id; ?> .slide-<?php echo ($i+1); ?> .slider-title{
				<?php if ( $settings->items[$i]->slider_title_size_medium <> '') { ?>
					font-size: <?php echo $settings->items[$i]->slider_title_size_medium; ?>px;
				<?php } ?>
				<?php if ( $settings->items[$i]->slider_title_max_width_medium <> '' ) { ?>
					max-width: <?php echo $settings->items[$i]->slider_title_max_width_medium; ?>%;
				<?php } ?>
			}
		<?php } ?>
		<?php if ( $settings->items[$i]->slider_text_size_medium <> '' || $settings->items[$i]->slider_text_max_width_medium <> '' ) { ?>
			.fl-node-<?php echo $id; ?> .slide-<?php echo ($i+1); ?> .slider-text{
				<?php if ( $settings->items[$i]->slider_text_size_medium <> '') { ?>
					font-size: <?php echo $settings->items[$i]->slider_text_size_medium; ?>px;
				<?php } ?>
				<?php if ( $settings->items[$i]->slider_text_max_width_medium <> '' ) { ?>
					max-width: <?php echo $settings->items[$i]->slider_text_max_width_medium; ?>%;
				<?php } ?>
			}
		<?php } ?>
	<?php endfor; ?>
}
@media only screen and ( max-width: <?php echo $global_settings->responsive_breakpoint; ?>px ) {
	<?php for($i = 0; $i < count($settings->items); $i++) : if(!is_object($settings->items[$i])) continue; ?>
		<?php if ( $settings->items[$i]->slider_title_size_responsive <> '' || $settings->items[$i]->slider_title_size_responsive <> '' ) { ?>
			.fl-node-<?php echo $id; ?> .slide-<?php echo ($i+1); ?> .slider-title{
				<?php if ( $settings->items[$i]->slider_title_size_responsive <> '') { ?>
					font-size: <?php echo $settings->items[$i]->slider_title_size_responsive; ?>px;
				<?php } ?>
				<?php if ( $settings->items[$i]->slider_title_max_width_responsive <> '' ) { ?>
					max-width: <?php echo $settings->items[$i]->slider_title_max_width_responsive; ?>%;
				<?php } ?>
			}
		<?php } ?>
		<?php if ( $settings->items[$i]->slider_text_size_responsive <> '' || $settings->items[$i]->slider_text_max_width_responsive <> '' ) { ?>
			.fl-node-<?php echo $id; ?> .slide-<?php echo ($i+1); ?> .slider-text{
				<?php if ( $settings->items[$i]->slider_text_size_responsive <> '') { ?>
					font-size: <?php echo $settings->items[$i]->slider_text_size_responsive; ?>px;
				<?php } ?>
				<?php if ( $settings->items[$i]->slider_text_max_width_responsive <> '' ) { ?>
					max-width: <?php echo $settings->items[$i]->slider_text_max_width_responsive; ?>%;
				<?php } ?>
			}
		<?php } ?>
	<?php endfor; ?>
}