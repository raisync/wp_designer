<?php
$output = '<div class="'.$module->get_classname().'">';
	$output .= '<div class="benefits-items '.$settings->column.'">';
			if ( $settings->categories != 'selected' || $settings->selected_categories == '' ) {
				$query_args = array(
					'post_type' => 'service',
					'posts_per_page' => $settings->totalpost,
					'orderby' => $settings->orderby,
					'order' => $settings->order,
					'offset' => $settings->offset,
				);
			} else {
				$query_args = array(
					'post_type' => 'service',
					'posts_per_page' => $settings->totalpost,
					'orderby' => $settings->orderby,
					'order' => $settings->order,
					'offset' => $settings->offset,
					'tax_query' => array( 
						array( 
							'taxonomy' => 'service_category', //or tag or custom taxonomy
							'field' => 'slug', 
							'terms' => $settings->selected_categories
						) 
					)
				);
			}
		$query = new WP_Query($query_args);
		while ($query->have_posts()) : $query->the_post(); 
			$output .= '<div class="benefits-item">';
				$photo = wp_get_attachment_image_src( get_post_thumbnail_id( $query->ID ), $settings->image_size );
				$photoURL = $photo[0] ? $photo[0] : '';
				if( $photoURL <> '' ) {
					$output .= '<div class="benefits-image" style=" background-image: url('.$photoURL.');"></div>'; 
				}
				$output .= '<div class="benefits-info">'; 
					if( $settings->title == 'true' ) {
						$output .= '<div class="benefits-title">'.get_the_title().'</div>'; 
					}
					if( $settings->content == 'true' ) {
						$output .= '<div class="benefits-content">'.nl2br(get_the_content()).'</div>'; 
					}
				$output .= '</div>'; 
			$output .=  '</div>'; 
		endwhile; wp_reset_query();
	$output .= '</div>';
$output .= '</div>';
echo $output;
?>