(function($) {
	$(function() {
		<?php 
			$autoplay = ( $settings->autoplay <> '' ) ? $settings->autoplay : 'false';
			$dots = ( $settings->show_dots <> '' ) ? $settings->show_dots : 'true';
			$nav = ( $settings->show_nav <> '' ) ? $settings->show_nav : 'true';
			$delay = $settings->autoplay_delay <> '' ? $settings->autoplay_delay : '7000';
			$speed = $settings->autoplay_speed <> '' ? $settings->autoplay_speed : '1500'; 
		?>
		var owl = $(".fl-node-<?php echo $id; ?> .owl-carousel");
		function sliderOwl() {
			owl.owlCarousel({
				items: 1,
				margin: 0,
				navText: ['',''],
				nav: false,
				dots: false,
				autoHeight: true,
				autoplayHoverPause: false,
				autoplay: <?php echo $autoplay; ?>,
				autoplayTimeout: <?php echo $delay ?>,
				autoplaySpeed: <?php echo $speed ?>,
				dragEndSpeed: <?php echo $speed ?>,
				fluidSpeed: <?php echo $speed ?>,
				smartSpeed: <?php echo $speed ?>,
				<?php for($i = 0; $i < count($settings->items); $i++) : if(!is_object($settings->items[$i])) continue; endfor; if ( $i > 1 ) { ?>
					loop: true,
				<?php } else { ?>
					loop: false,
					dots: false,
					nav: false,
					touchDrag: false,
					mouseDrag: false,
				<?php } ?>
				<?php if ( $settings->loop_animation == 'fade' ) { ?>
					animateOut: 'fadeOut',
					responsive : {
						0 : {
							mouseDrag: true,
						},
						1280 : {
							mouseDrag: false,
						}
					}
				<?php } ?>
			});
		}
        sliderOwl();
		
		$('body').on('click','.fl-field-responsive-toggle', function(){
			owl.trigger('destroy.owl.carousel');
			owl.html(owl.find('.owl-stage-outer').html()).removeClass('owl-loaded');
			setTimeout(function() {
				sliderOwl();
			}, 300);
		});
		
		<?php if ( $autoplay === 'true' ) { ?>
			$.fn.visible = function(partial) {
				var $t            = $(this),
					$w            = $(window),
					viewTop       = $w.scrollTop(),
					viewBottom    = viewTop + $w.height(),
					_top          = $t.offset().top,
					_bottom       = _top + $t.height(),
					compareTop    = partial === true ? _bottom : _top,
					compareBottom = partial === true ? _top : _bottom;		
				return ((compareBottom <= viewBottom) && (compareTop >= viewTop));
			};
			$(window).on("load scroll resize", function(){
				if (owl.visible(true)) {
					owl.trigger('play.owl.autoplay');
				} else {
					owl.trigger('stop.owl.autoplay');
				}
			});
			$(window).on("load scroll resize", function(){
				if (owl.visible(true)) {
					owl.trigger('play.owl.autoplay');
				} else {
					owl.trigger('stop.owl.autoplay');
				}
			});
		<?php } ?>
	});
	
})(jQuery);