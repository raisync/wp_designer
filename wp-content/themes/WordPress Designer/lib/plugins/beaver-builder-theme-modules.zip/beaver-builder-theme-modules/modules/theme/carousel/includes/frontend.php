<?php global $post; $style = $settings->item_style <> '' ? ' '.$settings->item_style : ''; $hoverStyle = $settings->item_hover_style <> '' ? ' '.$settings->item_hover_style : '';
$output = '<div class="owl-carousel '.$module->get_classname().$style.$hoverStyle.'">';
	if ( $settings->source != 'media-gallery' ) {
			/*setting*/
			if ( $settings->categories != 'selected' || $settings->selected_categories == '' ) {
				$query_args = array(
					'post_type' => 'portfolio',
					'posts_per_page' => $settings->totalpost,
					'orderby' => $settings->orderby,
					'order' => $settings->order,
					'offset' => $settings->offset,
				);
			} else {
				$query_args = array(
					'post_type' => 'portfolio',
					'posts_per_page' => $settings->totalpost,
					'orderby' => $settings->orderby,
					'order' => $settings->order,
					'offset' => $settings->offset,
					'tax_query' => array( 
						array( 
							'taxonomy' => 'portfolio_category', //or tag or custom taxonomy
							'field' => 'slug', 
							'terms' => $settings->selected_categories
						) 
					)
				);
			}
			$query = new WP_Query($query_args);
			while ($query->have_posts()) : $query->the_post();
				$postID = get_the_ID();
				$linkimage_src = $thumbnail_src = '';
				if ( $settings->lightbox === 'true' ) {
					$linkimage = wp_get_attachment_image_src( get_post_thumbnail_id( $postID ), 'large' );
					$linkimage_src = $linkimage[0];
				} else {
					$linkimage_src = get_permalink();
				}
				$thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $postID ), 'medium' );
				$thumbnail_src = $thumbnail[0];
				if ( !empty($thumbnail_src) ) {
					$bg_image = ' style=" background-image: url('.$thumbnail_src.'); "';
				}
				$output .= '<a href="'.$linkimage_src.'" class="carousel-item carouse-'.($i+1).'"'.$bg_image.' data-slb-group="simple-lightbox-'.$id.'" title="'.get_the_title().'">';
				if ( $settings->title == 'true' ) {
					$output .= '<span class="h4 carousel-title"><span>'.get_the_title().'</span></span>';
				}
				$output .= '</a>';
			endwhile; wp_reset_query();
		$output .= '</div>';
	} else {
		$images = $settings->media_gallery;
		if ( !empty($images) ) {
			foreach ( $images as $i => $image ) {
				$photo = FLBuilderPhoto::get_attachment_data($image);
				$photo_description = $photo_caption = '';
				if(!empty($photo->alt)) 		{ $photo_alt = htmlspecialchars($photo->alt); }
				if(!empty($photo->title)) 		{ $photo_title = htmlspecialchars($photo->title); }
				if(!empty($photo->description)) { $photo_description = htmlspecialchars($photo->description); }
				if(!empty($photo->caption)) 	{ $photo_caption = htmlspecialchars($photo->caption); }
				$photo_title = ($photo_title <> '') ? $photo_title : $photo_alt;
				
				$linkimage_src = $thumbnail_src = '';
				$linkimage = wp_get_attachment_image_src($image, 'large' );
				$linkimage_src = $linkimage[0];
				$thumbnail = wp_get_attachment_image_src($image, 'medium-large' ); 
				$thumbnail_src = $thumbnail[0];
				if ( !empty($thumbnail_src) ) {
					$bg_image = ' style=" background-image: url('.$thumbnail_src.'); "';
				}
				$output .= '<a href="'.$linkimage_src.'" class="carousel-item carouse-'.($i+1).'"'.$bg_image.' data-slb-group="simple-lightbox-'.$id.'" title="'.$photo_title.'">';
				if ( $settings->title == 'true' ) {
					$output .= '<span class="h4 carousel-title"><span>'.$photo_title.'</span></span>';
				}
				$output .= '</a>';
			}
		}
	}
$output .= '</div>';
echo $output;
?>