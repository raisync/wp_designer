<?php

/**
 * @class carouselModule
 */
class carouselModule extends FLBuilderModule {

	/** 
	 * @method __construct
	 */  
	public function __construct()
	{
		global $foldercategory;
		parent::__construct(array(
			'name'          	=> __('Carousel', 'fl-builder'),
			'description'   	=> __('Fullscreen Slideshow.', 'fl-builder'),
			'category'      	=> __($foldercategory, 'fl-builder'),
			'partial_refresh'	=> true
		));
		// Register and enqueue your own.
		$this->add_css( 'owl-carousel', FL_MODULE_THEME_URL . 'assets/owlcarousel/owl.carousel.css' );
		$this->add_css( 'owl-carousel-theme', FL_MODULE_THEME_URL . 'assets/owlcarousel/owl.theme.default.min.css' );
		$this->add_js( 'owl-carousel', FL_MODULE_THEME_URL . 'assets/owlcarousel/owl.carousel.min.js', array(), '', true );
	}
	/**
	 * @method get_classname
	 */
	public function get_classname()
	{
		$classname = 'carousel';
		return $classname;
	}
}

/*Module Image Size*/
add_image_size( 'carousel-thumb', 370 , 270, true );



// Get Categories
$taxonomy     = 'portfolio_category';
$hide_empty   = 0;
$args = array(
	'taxonomy'     => $taxonomy,
	'hide_empty'   => $hide_empty
);
$all_categories = get_categories( $args );
$posttypeCategories = array();
foreach ($all_categories as $sub_category1) {
	if($sub_category1->category_parent == 0) {
		$posttypeCategories[$sub_category1->slug] = ucfirst($sub_category1->name);
		/*level 2*/
		$args2 = array(
				'taxonomy'     => $taxonomy,
				'child_of'     => $sub_category1->term_id,
				'parent'       => $sub_category1->term_id,
				'hide_empty'   => $hide_empty
		);
		$sub_cats2 = get_categories( $args2 );
		if($sub_cats2) {
			foreach($sub_cats2 as $sub_category2) {
				$posttypeCategories[$sub_category2->slug] = '-- '.ucfirst($sub_category2->name);

				/*level 3*/
				$args3 = array(
					'taxonomy'     => $taxonomy,
					'child_of'     => $sub_category2->term_id,
					'parent'       => $sub_category2->term_id,
					'hide_empty'   => $hide_empty
				);
				$sub_cats3 = get_categories( $args3 );
				if($sub_cats3) {
					foreach($sub_cats3 as $sub_category3) {
						$posttypeCategories[$sub_category3->slug] = '--- '.ucfirst($sub_category3->name);

						/*level 4*/
						$args4 = array(
							'taxonomy'     => $taxonomy,
							'child_of'     => $sub_category3->term_id,
							'parent'       => $sub_category3->term_id,
							'hide_empty'   => $hide_empty
						);
						$sub_cats4 = get_categories( $args4 );
						if($sub_cats4) {
							foreach($sub_cats4 as $sub_category4) {
								$posttypeCategories[$sub_category4->slug] = '---- '.ucfirst($sub_category4->name);
							}
						}
					}
				}
			} 
		}
	}       
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('carouselModule', array(
	'slides'         => array(
		'title'         => __('Slides', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
					'source'         => array(
						'type'          => 'select',
						'label'         => __('Source', 'fl-builder'),
						'default'       => '',
						'options'       => array(
							'posttype-portfolio'    		=> __('Posttype - Portfolio', 'fl-builder'),
							'media-gallery'    		=> __('Media Gallery', 'fl-builder'),
						),
						'toggle'        => array(
							'posttype-portfolio'        => array(
								'fields'      	=> array('categories', 'button_link', 'totalpost', 'offset', 'order', 'orderby', 'lightbox'),
							),
							'media-gallery'        	=> array(
								'fields'        => array('media_gallery'),
							),
						)
					),
					'categories'         => array(
						'type'          => 'select',
						'label'         => __('Categories', 'fl-builder'),
						'default'       => '',
						'options'       => array(
							''    		=> __('All', 'fl-builder'),
							'selected'    		=> __('Selected', 'fl-builder'),
						),
						'toggle'        => array(
							'selected'        => array(
								'fields'        => array('selected_categories')
							),
						)
					),
					'selected_categories'         => array(
						'type'          => 'select',
						'label'         => __('Select Category', 'fl-builder'),
						'options'       => $posttypeCategories,
						'multi-select'  => true
					),
					'media_gallery'         => array(
						'type'          => 'multiple-photos',
						'label'         => __('Media Gallery', 'fl-builder'),
						'show_remove'	=> true,
					),
					'totalpost'         => array(
						'type'          => 'unit',
						'label'         => __('Total Post', 'fl-builder'),
						'default'       => __('9', 'fl-builder'),
						'placeholder'       => __('9', 'fl-builder'),
						'maxlength'     => '2',
						'size'          => '1',
					),
					'orderby'         => array(
						'type'          => 'select',
						'label'         => __('Order By', 'fl-builder'),
						'default'       => 'date',
						'options'       => array(
							'none'    		=> __('none', 'fl-builder'),
							'ID'    		=> __('ID', 'fl-builder'),
							'title'    		=> __('title', 'fl-builder'),
							'name'    		=> __('name', 'fl-builder'),
							'date'    		=> __('date', 'fl-builder'),
							'modified'    	=> __('modified', 'fl-builder'),
							'rand'    		=> __('rand', 'fl-builder'),
							'menu_order'    		=> __('menu_order', 'fl-builder'),
							''    		=> __('', 'fl-builder'),
						),
					),
					'order'         => array(
						'type'          => 'select',
						'label'         => __('Order By', 'fl-builder'),
						'default'       => '',
						'options'       => array(
							'DESC'    		=> __('DESCENDING', 'fl-builder'),
							'ASC'    		=> __('ASCENDING', 'fl-builder'),
						),
					),
					'offset'         => array(
						'type'          => 'unit',
						'label'         => __('Offset', 'fl-builder'),
						'default'       => '0',
						'help'       	=> 'Skip this many posts that match the specified criteria.',
					),
					'lightbox'         => array(
						'type'          => 'select',
						'label'         => __('Lightbox', 'fl-builder'),
						'default'       => 'grid-4',
						'options'       => array(
							'true'    		=> __('Yes', 'fl-builder'),
							'no'    		=> __('No', 'fl-builder'),
						)
					),
				)
			),
			'grid_setting'       => array(
				'title'         => 'Grids',
				'fields'        => array(
					'grid'         => array(
						'type'          => 'select',
						'label'         => __('Number of Column', 'fl-builder'),
						'default'       => '4',
						'options'       => array(
							'6'    		=> __('Column 6', 'fl-builder'),
							'5'    		=> __('Column 5', 'fl-builder'),
							'4'    		=> __('Column 4', 'fl-builder'),
							'3'    		=> __('Column 3', 'fl-builder'),
							'2'    		=> __('Column 2', 'fl-builder'),
							'1'    		=> __('Column 1', 'fl-builder'),
						)
					),
					'grid_tablet_landscape'         => array(
						'type'          => 'select',
						'label'         => __('Number of Column Tablet Landscape', 'fl-builder'),
						'default'       => '4',
						'options'       => array(
							'6'    		=> __('Column 6', 'fl-builder'),
							'5'    		=> __('Column 5', 'fl-builder'),
							'4'    		=> __('Column 4', 'fl-builder'),
							'3'    		=> __('Column 3', 'fl-builder'),
							'2'    		=> __('Column 2', 'fl-builder'),
							'1'    		=> __('Column 1', 'fl-builder'),
						)
					),
					'grid_tablet_portrait'         => array(
						'type'          => 'select',
						'label'         => __('Number of Column Tablet Portrait', 'fl-builder'),
						'default'       => '3',
						'options'       => array(
							'6'    		=> __('Column 6', 'fl-builder'),
							'5'    		=> __('Column 5', 'fl-builder'),
							'4'    		=> __('Column 4', 'fl-builder'),
							'3'    		=> __('Column 3', 'fl-builder'),
							'2'    		=> __('Column 2', 'fl-builder'),
							'1'    		=> __('Column 1', 'fl-builder'),
						)
					),
					'grid_mobile_landscape'         => array(
						'type'          => 'select',
						'label'         => __('Number of Column Mobile Landscape', 'fl-builder'),
						'default'       => '2',
						'options'       => array(
							'6'    		=> __('Column 6', 'fl-builder'),
							'5'    		=> __('Column 5', 'fl-builder'),
							'4'    		=> __('Column 4', 'fl-builder'),
							'3'    		=> __('Column 3', 'fl-builder'),
							'2'    		=> __('Column 2', 'fl-builder'),
							'1'    		=> __('Column 1', 'fl-builder'),
						)
					),
					'grid_mobile_portrait'         => array(
						'type'          => 'select',
						'label'         => __('Number of Column Mobile Portrait', 'fl-builder'),
						'default'       => '1',
						'options'       => array(
							'6'    		=> __('Column 6', 'fl-builder'),
							'5'    		=> __('Column 5', 'fl-builder'),
							'4'    		=> __('Column 4', 'fl-builder'),
							'3'    		=> __('Column 3', 'fl-builder'),
							'2'    		=> __('Column 2', 'fl-builder'),
							'1'    		=> __('Column 1', 'fl-builder'),
						)
					),
				)
			),
		)
	),
	'setting'        => array(
		'title'         => __('Settings', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
					'item_style'        => array(
						'type'          => 'select',
						'label'         => __('Item Style', 'fl-builder'),
						'default'       => '',
						'options'       => array(
							''      => __('Default', 'fl-builder'),
							'shadow'    => __('Shadow', 'fl-builder'),
						),
					),
					'item_hover_style'        => array(
						'type'          => 'select',
						'label'         => __('Item Hover Style', 'fl-builder'),
						'default'       => '',
						'options'       => array(
							''      => __('Default', 'fl-builder'),
							'hover-style-1'    => __('Style 1', 'fl-builder'),
							'hover-style-2'    => __('Style 2', 'fl-builder'),
							'hover-style-3'    => __('Style 3', 'fl-builder'),
						),
					),
					'title'        => array(
						'type'          => 'select',
						'label'         => __('Hover Title', 'fl-builder'),
						'default'       => 'true',
						'options'       => array(
							'true'    => __('Yes', 'fl-builder'),
							'false'      => __('No', 'fl-builder'),
						),
						'toggle'        => array(
							'true'        => array(
								'fields'        => array('title_bg_color', 'title_color')
							),
						),
					),
					'title_bg_color'        => array(
						'type'          => 'color',
						'label'         => __('Title Background Color', 'fl-builder'),
						'default'       => '',
						'show_reset'    => true,
					),
					'title_color'        => array(
						'type'          => 'color',
						'label'         => __('Title Color', 'fl-builder'),
						'default'       => '',
						'show_reset'    => true,
					),
					'title_size'        => array(
						'type'          => 'unit',
						'label'         => __('Title Size', 'fl-builder'),
						'default'       => '',
						'description'   => 'px',
						'preview'		=> array(
							'type'		=> 'css',
							'selector'		=> '.carousel .carousel-title',
							'property'      => 'font-size',
							'unit'      => 'px',
						),
					),
					'hover_overlay_color'        => array(
						'type'          => 'color',
						'label'         => __('Hover Overlay Color', 'fl-builder'),
						'default'       => '',
						'show_reset'    => true,
					),
				)
			),
			'slider_setting'       => array(
				'title'         => 'Slider',
				'fields'        => array(
					'spacing'        => array(
						'type'          => 'unit',
						'label'         => __('Spacing', 'fl-builder'),
						'description'   => 'px',
						'placeholder'   => '10',
					),
					'autoplay'        => array(
						'type'          => 'select',
						'label'         => __('Autoplay', 'fl-builder'),
						'default'       => 'true',
						'options'       => array(
							'true'    => __('Yes', 'fl-builder'),
							'false'      => __('No', 'fl-builder'),
						),
						'toggle'        => array(
							'true'        => array(
								'fields'        => array('autoplay_delay', 'autoplay_speed')
							),
						),
					),
					'loop'        => array(
						'type'          => 'select',
						'label'         => __('Loop', 'fl-builder'),
						'default'       => 'true',
						'options'       => array(
							'true'    => __('Yes', 'fl-builder'),
							'false'      => __('No', 'fl-builder'),
						),
					),
					'autoplay_delay'        => array(
						'type'          => 'unit',
						'label'         => __('Autoplay Delay', 'fl-builder'),
						'placeholder'       => '6000',
						'description'       => 'Millisecond',
					),
					'autoplay_speed'        => array(
						'type'          => 'unit',
						'label'         => __('Autoplay Speed', 'fl-builder'),
						'placeholder'       => '300',
						'description'       => 'Millisecond',
					),
					'show_dots'        => array(
						'type'          => 'select',
						'label'         => __('Enable Pagination', 'fl-builder'),
						'default'       => 'true',
						'options'       => array(
							'true'   	=> __('Yes', 'fl-builder'),
							'false'     => __('No', 'fl-builder'),
						),
						'toggle'        => array(
							'true'      => array(
								'sections'        => array( 'dots' ),
							),
						)
					),
					'show_nav'        => array(
						'type'          => 'select',
						'label'         => __('Enable Navigation', 'fl-builder'),
						'default'       => 'true',
						'options'       => array(
							'true'   	=> __('Yes', 'fl-builder'),
							'false'     => __('No', 'fl-builder'),
						),
						'toggle'        => array(
							'true'      => array(
								'sections'        => array( 'nav' ),
							),
						)
					),
				)
			),
			'dots'       => array(
				'title'         => 'Dots',
				'fields'        => array(             
					'dots_color'        => array(
						'type'          => 'color',
						'label'         => __('Dots Color', 'fl-builder'),
						'default'       => '',
						'show_reset'       => 'true',
						'preview'		=> array(
							'type'		=> 'css',
							'selector'		=> '.carousel .owl-dots .owl-dot',
							'property'      => 'background-color',
						),
					),   
					'dots_active_color'        => array(
						'type'          => 'color',
						'label'         => __('Dots Active Color', 'fl-builder'),
						'default'       => '',
						'show_reset'       => 'true',
						'preview'		=> array(
							'type'		=> 'css',
							'selector'		=> '.carousel .owl-dots .owl-dot.active',
							'property'      => 'background-color',
						),
					),
					'dots_size'        => array(
						'type'          => 'unit',
						'label'         => __('Dots Size', 'fl-builder'),
						'default'       => '',
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-dots .owl-dot',
									'property'      => 'width',
									'unit'      => 'px',
								),
								array(
									'selector'		=> '.carousel .owl-dots .owl-dot',
									'property'      => 'height',
									'unit'      => 'px',
								), 
								array(
									'selector'		=> '.carousel .flickity-page-dots .dot',
									'property'      => 'width',
									'unit'      => 'px',
								),
								array(
									'selector'		=> '.carousel .flickity-page-dots .dot',
									'property'      => 'height',
									'unit'      => 'px',
								), 
							),
						),
					),
					'dots_spacing'        => array(
						'type'          => 'unit',
						'label'         => __('Dots Spacing', 'fl-builder'),
						'default'       => '',
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-dots .owl-dot',
									'property'      => 'margin-left',
									'unit'      => 'px',
								),
								array(
									'selector'		=> '.carousel .owl-dots .owl-dot',
									'property'      => 'margin-right',
									'unit'      => 'px',
								), 
								array(
									'selector'		=> '.carousel .flickity-page-dots .dot',
									'property'      => 'margin-left',
									'unit'      => 'px',
								),
								array(
									'selector'		=> '.carousel .flickity-page-dots .dot',
									'property'      => 'margin-right',
									'unit'      => 'px',
								), 
							),
						),
					),
					'dots_margin_top'        => array(
						'type'          => 'unit',
						'label'         => __('Dots Top Margin', 'fl-builder'),
						'default'       => '',
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-dots',
									'property'      => 'margin-top',
									'unit'      => 'px',
								),
								array(
									'selector'		=> '.carousel .flickity-page-dots .dot',
									'property'      => 'margin-top',
									'unit'      => 'px',
								), 
							),
						),
					),
				)
			),
			'nav'       => array(
				'title'         => 'Navs',
				'fields'        => array(
					'nav_bg_color'        => array(
						'type'          => 'color',
						'label'         => __('Nav Background Color', 'fl-builder'),
						'default'       => '',
						'show_reset'    => true,
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-nav *',
									'property'      => 'background-color',
								),
							),
						),
					),
					'nav_border_color'        => array(
						'type'          => 'color',
						'label'         => __('Nav Border Color', 'fl-builder'),
						'default'       => '',
						'show_reset'    => true,
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-nav *',
									'property'      => 'border-color',
								),
							),
						),
					),
					'nav_color'        => array(
						'type'          => 'color',
						'label'         => __('Nav Color', 'fl-builder'),
						'default'       => '',
						'description'   => 'default: #000000',
						'show_reset'    => false,
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-nav *::before',
									'property'      => 'background-color',
								),
								array(
									'selector'		=> '.carousel .owl-nav *::after',
									'property'      => 'background-color',
								), 
							),
						),
					),
					'nav_bg_color_hover'        => array(
						'type'          => 'color',
						'label'         => __('Nav Background Color Hover', 'fl-builder'),
						'default'       => '',
						'show_reset'    => true,
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-nav *:hover',
									'property'      => 'background-color',
								),
								array(
									'selector'		=> '.carousel .owl-nav *:hover',
									'property'      => 'background-color',
								), 
							),
						),
					),
					'nav_border_color_hover'        => array(
						'type'          => 'color',
						'label'         => __('Nav Border Color Hover', 'fl-builder'),
						'default'       => '',
						'show_reset'    => true,
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-nav *:hover',
									'property'      => 'border-color',
								),
							),
						),
					),
					'nav_color_hover'        => array(
						'type'          => 'color',
						'label'         => __('Nav Color Hover', 'fl-builder'),
						'default'       => '',
						'show_reset'    => true,
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-nav *:hover::before',
									'property'      => 'background-color',
								),
								array(
									'selector'		=> '.carousel .owl-nav *:hover::after',
									'property'      => 'background-color',
								), 
							),
						),
					),
					'nav_size'        => array(
						'type'          => 'unit',
						'label'         => __('Nav Size', 'fl-builder'),
						'default'       => '',
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-nav *',
									'property'      => 'width',
									'unit'      => 'px',
								),
								array(
									'selector'		=> '.carousel .owl-nav *',
									'property'      => 'height',
									'unit'      => 'px',
								), 
							),
						),
					),
					'nav_radius'        => array(
						'type'          => 'unit',
						'label'         => __('Nav Radius', 'fl-builder'),
						'default'       => '',
						'description'   => 'px',
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-nav *',
									'property'      => 'border-radius',
									'unit'      => 'px',
								),
								array(
									'selector'		=> '.carousel .owl-nav *',
									'property'      => 'border-radius',
									'unit'      => 'px',
								),
							),
						),
					),
					'nav_spacing'        => array(
						'type'          => 'unit',
						'label'         => __('Nav Spacing', 'fl-builder'),
						'default'       => '',
						'description'   => 'px',
						'placeholder'   => '-60',
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-nav .owl-prev',
									'property'      => 'left',
									'unit'      => 'px',
								),
								array(
									'selector'		=> '.carousel .owl-nav .owl-next',
									'property'      => 'right',
									'unit'      => 'px',
								), 
							),
						),
					),
					'nav_thick'        => array(
						'type'          => 'unit',
						'label'         => __('Nav Arrow Thickness', 'fl-builder'),
						'default'       => '',
						'description'   => 'px',
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-nav *::before',
									'property'      => 'width',
									'unit'      => 'px',
								),
								array(
									'selector'		=> '.carousel .owl-nav *::after',
									'property'      => 'width',
									'unit'      => 'px',
								),
							),
						),
					),
					'nav_border_thick'        => array(
						'type'          => 'unit',
						'label'         => __('Nav Border Thickness', 'fl-builder'),
						'default'       => '',
						'description'   => 'px',
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-nav *',
									'property'      => 'border-width',
									'unit'      => 'px',
								),
							),
						),
					),
					'nav_arrow_radius'        => array(
						'type'          => 'unit',
						'label'         => __('Nav Arrow Radius', 'fl-builder'),
						'default'       => '',
						'description'   => 'px',
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-nav *::before',
									'property'      => 'border-radius',
									'unit'      => 'px',
								),
								array(
									'selector'		=> '.carousel .owl-nav *::after',
									'property'      => 'border-radius',
									'unit'      => 'px',
								),
							),
						),
					),
					'nav_margin_top'        => array(
						'type'          => 'unit',
						'label'         => __('Nav Top Margin', 'fl-builder'),
						'default'       => '',
						'preview'		=> array(
							'type'		=> 'css',
							'rules'           => array(
								array(
									'selector'		=> '.carousel .owl-nav',
									'property'      => 'margin-top',
									'unit'      => 'px',
								),
							),
						),
					),
				)
			),
		)
	)
));