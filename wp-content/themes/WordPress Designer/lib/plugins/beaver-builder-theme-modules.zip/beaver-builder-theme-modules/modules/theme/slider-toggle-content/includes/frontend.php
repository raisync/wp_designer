<?php	
$output = '<div class="'.$module->get_classname().'">';
	$output .= '<div class="owl-carousel slides '.$settings->loop_animation.'">';
		for($i = 0; $i < count($settings->items); $i++) : if(!is_object($settings->items[$i])) continue;
			$output .= '<div class="slide-item slide-'.($i+1).' '.$settings->items[$i]->slider_style.'">';
					$output .= '<div class="fl-row-fixed-width">';
						$output .= '<div class="slider-info">';
							$output .='<div class="slider-info-content">';
								if ( !empty( $settings->items[$i]->slider_title ) ) {
									$output .='<h2 class="slider-title">'.$settings->items[$i]->slider_title.'</h2>';
								}
								if ( !empty( $settings->items[$i]->slider_text ) ) {
									$output .='<p class="slider-text">';
										$output .= nl2br($settings->items[$i]->slider_text);
									$output .='</p>';
								}
							$output .='</div>';
						$output .= '</div>';
					$output .= '</div>';
			$output .= '</div>';
		endfor;
	$output .= '</div>';

	$output .= '<div class="slider-toggles-button">';
		$output .= '<div class="fl-row-fixed-width">';
			$output .= '<div class="owl-carousel slider-toggles-button-wrapper">';
				for($i = 0; $i < count($settings->toggles_item); $i++) : if(!is_object($settings->toggles_item[$i])) continue;
				$output .= '
					<figure class="slider-toggles-item item-'.($i+1).'">';
						$photo = '';
						$photo = FLBuilderPhoto::get_attachment_data($settings->toggles_item[$i]->toggles_item_image);
						$photo_alt = ($photo->alt <> '') ? $photo->alt : $photo->title;
						$photo_title = ($photo->title <> '') ? $photo->title : $photo->alt;
						$photo_thumb = wp_get_attachment_image_src($photo->id, 'slider-toggle-thumb');
						$output .= '
						<img src="'.$photo_thumb[0].'" alt="'.$photo_alt.'">
						<figcaption>
							<h3>'.$settings->toggles_item[$i]->toggles_item_title.'</h3>
							<i class="fa fa-angle-right" aria-hidden="true"></i>
						</figcaption>
					</figure>';
				endfor;
			$output .= '</div>';
		$output .= '</div>';
	$output .= '</div>';

	$output .= '<div class="slider-toggles-content">';
		$output .= '<div class="fl-row-fixed-width">';
			$output .= '<div class="slider-toggles-content-wrapper">';
				for($i = 0; $i < count($settings->toggles_item); $i++) : if(!is_object($settings->toggles_item[$i])) continue;
				$output .= '
					<div class="slider-toggles-content-item item-'.($i+1).'">';
						$image = '';
						$image = FLBuilderPhoto::get_attachment_data($settings->toggles_item[$i]->toggles_item_image);
						$image_alt = ($image->alt <> '') ? $image->alt : $image->title;
						$image_title = ($image->title <> '') ? $image->title : $image->alt;
						$image_thumb = wp_get_attachment_image_src($image->id, 'slider-toggle-content-images');
						$output .= '
						<figure class="slider-toggles-content-image">
							<img src="'.$image_thumb[0].'" alt="'.$image_alt.'">
						</figure>
						<div class="slider-toggles-content-text">
							<h3 class="title">'.$settings->toggles_item[$i]->toggles_item_title.'</h3>
							<section class="desc" data-scrollbar>'.$settings->toggles_item[$i]->toggles_item_text.'</section>
							<h4 class="data-title">'.$settings->toggles_item[$i]->toggles_item_table_title.'</h4>
							<div class="data-table">
								<div class="data-row">
									<div class="data-cell">
										<h4>'.$settings->toggles_item[$i]->toggles_item_table_col_1_title.'</h4>
										<p>'.$settings->toggles_item[$i]->toggles_item_table_col_1_text.'</p>
									</div>
									<div class="data-cell">
										<h4>'.$settings->toggles_item[$i]->toggles_item_table_col_2_title.'</h4>
										<p>'.$settings->toggles_item[$i]->toggles_item_table_col_2_text.'</p>
									</div>
									<div class="data-cell">
										<h4>'.$settings->toggles_item[$i]->toggles_item_table_col_3_title.'</h4>
										<p>'.$settings->toggles_item[$i]->toggles_item_table_col_3_text.'</p>
									</div>
								</div>
							</div>
						</div>';
						$output .= '<div class="slider-toggles-content-testimonial">';
							$query_args = array(
								'post_type' => 'testimonial',
								'posts_per_page' => 1,
								'orderby' => $settings->toggles_item[$i]->testimonial_orderby,
								'order' => $settings->toggles_item[$i]->testimonial_order,
								'tax_query' => array( 
									array( 
										'taxonomy' => 'testimonial_category', //or tag or custom taxonomy
										'field' => 'slug', 
										'terms' => $settings->toggles_item[$i]->testimonial_categories
									) 
								)
							);
							$query = new WP_Query($query_args);
							while ($query->have_posts()) : $query->the_post(); 
								$photo = wp_get_attachment_image_src( get_post_thumbnail_id( $query->ID ), $settings->image_size );
								$photoURL = $photo[0] ? $photo[0] : $module->url.'/images/avatar.png';
								$output .= '
								<blockqoute class="slider-toggles-testimonial">
									<div class="message"><div class="message-container" data-scrollbar>'.get_the_content().'</div></div>
									<figure class="avatar">
										<img src="'.$photoURL.'" alt="avatar">
										<figcaption>
											<h5 class="name">'.get_the_title().'</h5>
											<div class="position">'.get_field('company').'</div>
										</figcaption>
									</figure>
								</blockqoute>'; 
							endwhile; wp_reset_query();
						$output .= '</div>
					</div>';
				endfor;
			$output .= '</div>';
		$output .= '</div>';
	$output .= '</div>';
	
$output .= '</div>';
echo $output;
?>