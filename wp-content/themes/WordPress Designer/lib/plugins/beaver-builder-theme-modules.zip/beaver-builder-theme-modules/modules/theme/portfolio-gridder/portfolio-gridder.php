<?php
/**
 * @class portfolioGridderModule
 */
class portfolioGridderModule extends FLBuilderModule {

	/** 
	 * @method __construct
	 */  
	public function __construct()
	{
		global $foldercategory;
		parent::__construct(array(
			'name'          	=> __('Portfolio - Gridder', 'fl-builder'),
			'description'   	=> __('Display Gridder Expanded from Posttype.', 'fl-builder'),
			'category'      	=> __($foldercategory, 'fl-builder'),
			'partial_refresh'	=> true
		));
		// Register and enqueue your own.
		$this->add_css( 'gridder', $this->url . 'css/jquery.gridder.min.css' );
		$this->add_js( 'gridder', $this->url . 'js/jquery.gridder.js', array(), '', true );
	}
	
	/**
	 * @method get_classname
	 */
	public function get_classname()
	{
		$classname = 'portfolio-gridder';
		return $classname;
	}
}

/*Testimonial Avatar Size*/
add_image_size( 'portfolio-gridder-large', 485 , 422, true );



// Get Categories
$taxonomy     = 'portfolio_category';
$hide_empty   = 0;
$args = array(
	'taxonomy'     => $taxonomy,
	'hide_empty'   => $hide_empty
);
$all_categories = get_categories( $args );
$posttypeCategories = array();
foreach ($all_categories as $sub_category1) {
	if($sub_category1->category_parent == 0) {
		$posttypeCategories[$sub_category1->slug] = ucfirst($sub_category1->name);
		/*level 2*/
		$args2 = array(
				'taxonomy'     => $taxonomy,
				'child_of'     => $sub_category1->term_id,
				'parent'       => $sub_category1->term_id,
				'hide_empty'   => $hide_empty
		);
		$sub_cats2 = get_categories( $args2 );
		if($sub_cats2) {
			foreach($sub_cats2 as $sub_category2) {
				$posttypeCategories[$sub_category2->slug] = '-- '.ucfirst($sub_category2->name);

				/*level 3*/
				$args3 = array(
					'taxonomy'     => $taxonomy,
					'child_of'     => $sub_category2->term_id,
					'parent'       => $sub_category2->term_id,
					'hide_empty'   => $hide_empty
				);
				$sub_cats3 = get_categories( $args3 );
				if($sub_cats3) {
					foreach($sub_cats3 as $sub_category3) {
						$posttypeCategories[$sub_category3->slug] = '--- '.ucfirst($sub_category3->name);

						/*level 4*/
						$args4 = array(
							'taxonomy'     => $taxonomy,
							'child_of'     => $sub_category3->term_id,
							'parent'       => $sub_category3->term_id,
							'hide_empty'   => $hide_empty
						);
						$sub_cats4 = get_categories( $args4 );
						if($sub_cats4) {
							foreach($sub_cats4 as $sub_category4) {
								$posttypeCategories[$sub_category4->slug] = '---- '.ucfirst($sub_category4->name);
							}
						}
					}
				}
			} 
		}
	}       
}


/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('portfolioGridderModule', array(
	'slides'         => array(
		'title'         => __('General', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
					'categories'         => array(
						'type'          => 'select',
						'label'         => __('Categories', 'fl-builder'),
						'default'       => '',
						'options'       => array(
							''    		=> __('All', 'fl-builder'),
							'selected'    		=> __('Selected', 'fl-builder'),
						),
						'toggle'        => array(
							'selected'        => array(
								'fields'        => array('selected_categories')
							),
						)
					),
					'selected_categories'         => array(
						'type'          => 'select',
						'label'         => __('Select Category', 'fl-builder'),
						'options'       => $posttypeCategories,
						'multi-select'  => true
					),
				)
			),
			'content'       => array(
				'title'         => 'Content',
				'fields'        => array(
					'totalpost'         => array(
						'type'          => 'unit',
						'label'         => __('Total Post', 'fl-builder'),
						'default'       => __('9', 'fl-builder'),
						'placeholder'       => __('9', 'fl-builder'),
						'maxlength'     => '2',
						'size'          => '1',
					),
					'orderby'         => array(
						'type'          => 'select',
						'label'         => __('Order By', 'fl-builder'),
						'default'       => 'date',
						'options'       => array(
							'none'    		=> __('none', 'fl-builder'),
							'ID'    		=> __('ID', 'fl-builder'),
							'title'    		=> __('title', 'fl-builder'),
							'name'    		=> __('name', 'fl-builder'),
							'date'    		=> __('date', 'fl-builder'),
							'modified'    	=> __('modified', 'fl-builder'),
							'rand'    		=> __('rand', 'fl-builder'),
							'menu_order'    		=> __('menu_order', 'fl-builder'),
							''    		=> __('', 'fl-builder'),
						),
					),
					'order'         => array(
						'type'          => 'select',
						'label'         => __('Order By', 'fl-builder'),
						'default'       => 'ASC',
						'options'       => array(
							'DESC'    		=> __('DESCENDING', 'fl-builder'),
							'ASC'    		=> __('ASCENDING', 'fl-builder'),
						),
					),
					'offset'         => array(
						'type'          => 'unit',
						'label'         => __('Offset', 'fl-builder'),
						'default'       => '0',
						'help'       	=> 'Skip this many posts that match the specified criteria.',
					),
				)
			),
			'grid'       => array(
				'title'         => 'Grids',
				'fields'        => array(
					'grid'         => array(
						'type'          => 'select',
						'label'         => __('Number of Column', 'fl-builder'),
						'default'       => 'grid-4',
						'options'       => array(
							'grid-column-6'    		=> __('Column 6', 'fl-builder'),
							'grid-column-5'    		=> __('Column 5', 'fl-builder'),
							'grid-column-4'    		=> __('Column 4', 'fl-builder'),
							'grid-column-3'    		=> __('Column 3', 'fl-builder'),
							'grid-column-2'    		=> __('Column 2', 'fl-builder'),
							'grid-column-1'    		=> __('Column 1', 'fl-builder'),
						)
					),
					'grid_spacing'         => array(
						'type'          => 'unit',
						'label'         => __('Column Spacing', 'fl-builder'),
						'default'       => '20',
						'placeholder'       => '20',
						'description'       => 'px',
					),
				)
			),
		)
	),
));