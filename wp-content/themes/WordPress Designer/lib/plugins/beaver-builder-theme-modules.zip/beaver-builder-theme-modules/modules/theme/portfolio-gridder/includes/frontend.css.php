.fl-node-<?php echo $id; ?> .gridder-button::after {
	background-image: url(<?php echo $module->url; ?>/img/beer-overlay.png);
}
.fl-node-<?php echo $id; ?> .gridder-show.loading {
	background-image: url(<?php echo $module->url; ?>/img/loading-spin.svg);
}

<?php if ( $settings->grid_spacing <> '' ) { ?>
	.fl-node-<?php echo $id; ?> .gridder { width: calc(100% + <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(100% + <?php echo $settings->grid_spacing; ?>px); }
	.fl-node-<?php echo $id; ?> .gridder-list:nth-child(n) { margin: 0 <?php echo $settings->grid_spacing; ?>px <?php echo $settings->grid_spacing; ?>px 0; }

	@media only screen and ( max-width: 1663px ) { 
		.fl-node-<?php echo $id; ?> .fl-row-content.fl-row-full-width .grid-column-5 .gridder-list,
		.fl-node-<?php echo $id; ?> .fl-row-content.fl-row-full-width .grid-column-6 .gridder-list { width: calc(25% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(25% - <?php echo $settings->grid_spacing; ?>px); } 
	}
	@media only screen and ( max-width: 1080px ) { 
		.fl-node-<?php echo $id; ?> .grid-column-5 .gridder-list,
		.fl-node-<?php echo $id; ?> .grid-column-6 .gridder-list { width: calc(25% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(25% - <?php echo $settings->grid_spacing; ?>px); } 
	}
	@media only screen and ( min-width: 1024px ) { 
		.fl-node-<?php echo $id; ?> .grid-column-1 .gridder-list { width: calc(100% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(100% - <?php echo $settings->grid_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .grid-column-2 .gridder-list { width: calc(50% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(50% - <?php echo $settings->grid_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .grid-column-3 .gridder-list { width: calc(33.33% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(33.33% - <?php echo $settings->grid_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .grid-column-4 .gridder-list { width: calc(25% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(25% - <?php echo $settings->grid_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .grid-column-5 .gridder-list {  width: calc(20% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(20% - <?php echo $settings->grid_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .grid-column-6 .gridder-list { width: calc(16.666% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(16.666% - <?php echo $settings->grid_spacing; ?>px); }
	}
	@media only screen and ( max-width: 1023px ) { 
		.fl-node-<?php echo $id; ?> .grid-column-1 .gridder-list { width: calc(100% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(100% - <?php echo $settings->grid_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .grid-column-2 .gridder-list { width: calc(50% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(50% - <?php echo $settings->grid_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .grid-column-3 .gridder-list { width: calc(33.33% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(33.33% - <?php echo $settings->grid_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .grid-column-4 .gridder-list { width: calc(25% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(25% - <?php echo $settings->grid_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .grid-column-5 .gridder-list,
		.fl-node-<?php echo $id; ?> .grid-column-6 .gridder-list { width: calc(33.33% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(33.33% - <?php echo $settings->grid_spacing; ?>px); } 
	}
	@media only screen and ( max-width: 767px ) { 
		.grid-column-1 .gridder-list,
		.fl-node-<?php echo $id; ?> .grid-column-2 .gridder-list { width: calc(100% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(100% - <?php echo $settings->grid_spacing; ?>px); } 
		.fl-node-<?php echo $id; ?> .grid-column-3 .gridder-list,
		.fl-node-<?php echo $id; ?> .grid-column-4 .gridder-list { width: calc(50% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(50% - <?php echo $settings->grid_spacing; ?>px); } 
		.fl-node-<?php echo $id; ?> .grid-column-5 .gridder-list,
		.fl-node-<?php echo $id; ?> .grid-column-6 .gridder-list { width: calc(33.33% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(33.33% - <?php echo $settings->grid_spacing; ?>px); } 
	}
	@media only screen and ( max-width: 530px ) { 
		.fl-node-<?php echo $id; ?> .grid-column-1 .gridder-list,
		.fl-node-<?php echo $id; ?> .grid-column-2 .gridder-list,
		.fl-node-<?php echo $id; ?> .grid-column-3 .gridder-list,
		.fl-node-<?php echo $id; ?> .grid-column-4 .gridder-list,
		.fl-node-<?php echo $id; ?> .grid-column-5 .gridder-list,
		.fl-node-<?php echo $id; ?> .grid-column-6 .gridder-list { width: calc(100% - <?php echo $settings->grid_spacing; ?>px); width: -webkit-calc(100% - <?php echo $settings->grid_spacing; ?>px); } 
	}
<?php } ?>