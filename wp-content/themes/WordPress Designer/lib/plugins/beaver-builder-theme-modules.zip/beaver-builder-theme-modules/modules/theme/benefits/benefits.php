<?php
/**
 * @class benefitsModule
 */
class benefitsModule extends FLBuilderModule {

	/** 
	 * @method __construct
	 */  
	public function __construct()
	{
		global $foldercategory;
		parent::__construct(array(
			'name'          	=> __('Benefits', 'fl-builder'),
			'description'   	=> __('Display Benefits from Posttype.', 'fl-builder'),
			'category'      	=> __($foldercategory, 'fl-builder'),
			'partial_refresh'	=> true
		));
	}
	
	/**
	 * @method get_classname
	 */
	public function get_classname()
	{
		$classname = 'benefits '.$this->settings->style;
		return $classname;
	}
}

/*Testimonial Avatar Size*/
add_image_size( 'benefits-photo', 160 , 130 );


// Get Categories
$taxonomy     = 'service_category';
$hide_empty   = 0;
$args = array(
	'taxonomy'     => $taxonomy,
	'hide_empty'   => $hide_empty
);
$all_categories = get_categories( $args );
$posttypeCategories = array();
foreach ($all_categories as $sub_category1) {
	if($sub_category1->category_parent == 0) {
		$posttypeCategories[$sub_category1->slug] = ucfirst($sub_category1->name);
		/*level 2*/
		$args2 = array(
				'taxonomy'     => $taxonomy,
				'child_of'     => $sub_category1->term_id,
				'parent'       => $sub_category1->term_id,
				'hide_empty'   => $hide_empty
		);
		$sub_cats2 = get_categories( $args2 );
		if($sub_cats2) {
			foreach($sub_cats2 as $sub_category2) {
				$posttypeCategories[$sub_category2->slug] = '-- '.ucfirst($sub_category2->name);

				/*level 3*/
				$args3 = array(
					'taxonomy'     => $taxonomy,
					'child_of'     => $sub_category2->term_id,
					'parent'       => $sub_category2->term_id,
					'hide_empty'   => $hide_empty
				);
				$sub_cats3 = get_categories( $args3 );
				if($sub_cats3) {
					foreach($sub_cats3 as $sub_category3) {
						$posttypeCategories[$sub_category3->slug] = '--- '.ucfirst($sub_category3->name);

						/*level 4*/
						$args4 = array(
							'taxonomy'     => $taxonomy,
							'child_of'     => $sub_category3->term_id,
							'parent'       => $sub_category3->term_id,
							'hide_empty'   => $hide_empty
						);
						$sub_cats4 = get_categories( $args4 );
						if($sub_cats4) {
							foreach($sub_cats4 as $sub_category4) {
								$posttypeCategories[$sub_category4->slug] = '---- '.ucfirst($sub_category4->name);
							}
						}
					}
				}
			} 
		}
	}       
}


/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('benefitsModule', array(
	'general'         => array(
		'title'         => __('General', 'fl-builder'),
		'sections'      => array(
			'general'       => array(
				'title'         => '',
				'fields'        => array(
					'categories'         => array(
						'type'          => 'select',
						'label'         => __('Categories', 'fl-builder'),
						'default'       => '',
						'options'       => array(
							''    		=> __('All', 'fl-builder'),
							'selected'    		=> __('Selected', 'fl-builder'),
						),
						'toggle'        => array(
							'selected'        => array(
								'fields'        => array('selected_categories')
							),
						)
					),
					'selected_categories'         => array(
						'type'          => 'select',
						'label'         => __('Select Category', 'fl-builder'),
						'options'       => $posttypeCategories,
						'multi-select'  => true
					),
					'column'         => array(
						'type'          => 'select',
						'label'         => __('Number of Column', 'fl-builder'),
						'default'       => 'column-3',
						'options'       => array(
							'column-1'    		=> __('Column 1', 'fl-builder'),
							'column-2'    		=> __('Column 2', 'fl-builder'),
							'column-3'    		=> __('Column 3', 'fl-builder'),
							'column-4'    		=> __('Column 4', 'fl-builder'),
							'column-5'    		=> __('Column 5', 'fl-builder'),
							'column-6'    		=> __('Column 6', 'fl-builder'),
						)
					),
					'column_spacing'           => array(
						'type'          => 'unit',
						'label'         => __( 'Column Spacing', 'fl-builder' ),
						'default' 		=> '30',
						'maxlength'     => '3',
						'size'          => '4',
						'description'   => 'px',
					),
					'totalpost'         => array(
						'type'          => 'unit',
						'label'         => __('Total Item', 'fl-builder'),
						'default'       => __('6', 'fl-builder'),
						'placeholder'       => __('6', 'fl-builder'),
						'maxlength'     => '2',
						'size'          => '1',
					),
					'order'         => array(
						'type'          => 'select',
						'label'         => __('Order Sorting', 'fl-builder'),
						'default'       => 'ASC',
						'options'       => array(
							'DESC'    		=> __('DESCENDING', 'fl-builder'),
							'ASC'    		=> __('ASCENDING', 'fl-builder'),
						)
					),
					'orderby'         => array(
						'type'          => 'select',
						'label'         => __('Order By', 'fl-builder'),
						'default'       => 'date',
						'options'       => array(
							'none'    		=> __('none', 'fl-builder'),
							'ID'    		=> __('ID', 'fl-builder'),
							'title'    		=> __('title', 'fl-builder'),
							'name'    		=> __('name', 'fl-builder'),
							'date'    		=> __('date', 'fl-builder'),
							'modified'    	=> __('modified', 'fl-builder'),
							'rand'    		=> __('rand', 'fl-builder'),
							'menu_order'    		=> __('menu_order', 'fl-builder'),
							''    		=> __('', 'fl-builder'),
						),
					),
					'image_size'    => array(
						'type'          => 'photo-sizes',
						'label'         => __('Size', 'fl-builder'),
						'default'       => 'benefits-photo'
					),
					'title'         => array(
						'type'          => 'select',
						'label'         => __('Show Title', 'fl-builder'),
						'default'       => 'true',
						'options'       => array(
							'true'    		=> __('Yes', 'fl-builder'),
							'false'    		=> __('No', 'fl-builder'),
						)
					),
					'content'         => array(
						'type'          => 'select',
						'label'         => __('Show Content', 'fl-builder'),
						'default'       => 'true',
						'options'       => array(
							'true'    		=> __('Yes', 'fl-builder'),
							'false'    		=> __('No', 'fl-builder'),
						)
					),
					'max_width'         => array(
						'type'          => 'unit',
						'label'         => __('Max Width', 'fl-builder'),
						'default'       => '',
						'description'       => 'px',
					),
				)
			)
		)
	),
));