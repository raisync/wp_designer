<?php

/**
 * @class TextBlockModule
 */
class TextBlockModule extends FLBuilderModule {

	/** 
	 * @method __construct
	 */  
	public function __construct()
	{
		parent::__construct(array(
			'name'          	=> __('Text Editor', 'fl-builder'),
			'description'   	=> __('A WYSIWYG text editor.', 'fl-builder'),
			'category'      	=> __('Basic Modules', 'fl-builder'),
			'partial_refresh'	=> true
		));
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('TextBlockModule', array(
	'general'       => array( // Tab
		'title'         => __('General', 'fl-builder'), // Tab title
		'sections'      => array( // Tab Sections
			'general'       => array( // Section
				'title'         => '', // Section Title
				'fields'        => array( // Section Fields
					'text'          => array(
						'type'          => 'editor',
						'label'         => '',
						'rows'          => 13,
						'wpautop'		=> false,
						'preview'         => array(
							'type'             => 'text',
							'selector'         => '.rich-text-advanced'  
						)
					)
				)
			),
		)
	),
	'setting'       => array( // Tab
		'title'         => __('Setting', 'fl-builder'), // Tab title
		'sections'      => array( // Tab Sections
			'fonts'         => array(
				'title'         => '',
				'fields'        => array(
					'font_family'         => array(
						'type'          => 'font',
						'label'         => __('Font Family', 'fl-builder'),
						'default'       => array(
							'family'        => 'Default',
							'weight'        => 400
						),
						'preview'         => array(
							'type'            => 'font',
							'selector'      => '.rich-text-advanced *:not(i):not(h1):not(h2):not(h3):not(h4):not(h5):not(h6)',
						)
					),
					'font_weight'         => array(
						'type'          => 'select',
						'label'         => __('Default Font Weight', 'fl-builder'),
						'default' 		=> '',
						'options'       => array(
							''    	=> __('Default', 'fl-builder'),
							'100'    	=> __('100 Thin', 'fl-builder'),
							'200'    	=> __('200 Extra-Light', 'fl-builder'),
							'300'    	=> __('300 Light', 'fl-builder'),
							'400'    	=> __('400 Regular', 'fl-builder'),
							'500'    	=> __('500 Medium', 'fl-builder'),
							'600'    	=> __('600 Semi-Bold', 'fl-builder'),
							'700'    	=> __('700 Bold', 'fl-builder'),
							'800'    	=> __('800 Extra-Bold', 'fl-builder'),
							'900'    	=> __('900 Ultra-Bold', 'fl-builder'),
						),
						'preview'       => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced *:not(i):not(h1):not(h2):not(h3):not(h4):not(h5):not(h6)',
							'property'      => 'font-weight',
						),
						'help'   		=> 'Its depend to the font family if the following font-weight supported.',
					),
					'font_size' => array(
						'type'          => 'unit',
						'label'         => __( 'Font Size', 'fl-builder' ),
						'default'       => '',
						'description'	=> 'px',
						'preview'         => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced *:not(i):not(h1):not(h2):not(h3):not(h4):not(h5):not(h6)',
							'property'      => 'font-size',
							'unit'        	=> 'px',
						)
					),
					'color' => array(
						'type'          => 'color',
						'label'         => __( 'Font Color', 'fl-builder' ),
						'default'       => '',
						'show_remove'	=> true,
						'preview'         => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced *:not(i):not(h1):not(h2):not(h3):not(h4):not(h5):not(h6)',
							'property'      => 'color',
						)
					),
					'link_color' => array(
						'type'          => 'color',
						'label'         => __( 'Link Color', 'fl-builder' ),
						'default'       => '',
						'show_remove'	=> true,
						'preview'         => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced *:not(i):not(h1):not(h2):not(h3):not(h4):not(h5):not(h6) a',
							'property'      => 'color',
						)
					),
					'link_hover_color' => array(
						'type'          => 'color',
						'label'         => __( 'Link Hover Color', 'fl-builder' ),
						'default'       => '',
						'show_remove'	=> true,
						'preview'         => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced *:not(i):not(h1):not(h2):not(h3):not(h4):not(h5):not(h6) a:hover',
							'property'      => 'color',
						)
					),
				)
			),
			'heading'         => array(
				'title'         => 'Heading H1-H6',
				'fields'        => array(
					'font_family_heading'         => array(
						'type'          => 'font',
						'label'         => __('Heading Font Family', 'fl-builder'),
						'default'       => array(
							'family'        => 'Default',
							'weight'        => 400
						),
						'preview'         => array(
							'type'            => 'font',
							'selector'      => '.rich-text-advanced h1, .rich-text-advanced h2, .rich-text-advanced h3, .rich-text-advanced h4, .rich-text-advanced h5, .rich-text-advanced h6',
						)
					),
					'heading_color' => array(
						'type'          => 'color',
						'label'         => __( 'Heading Color', 'fl-builder' ),
						'default'       => '',
						'show_remove'	=> true,
						'preview'         => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced h1, .rich-text-advanced h2, .rich-text-advanced h3, .rich-text-advanced h4, .rich-text-advanced h5, .rich-text-advanced h6',
							'property'      => 'color',
						)
					),
					'heading_link_color' => array(
						'type'          => 'color',
						'label'         => __( 'Heading Link Color', 'fl-builder' ),
						'default'       => '',
						'show_remove'	=> true,
						'preview'         => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced h1 a, .rich-text-advanced h2 a, .rich-text-advanced h3 a, .rich-text-advanced h4 a, .rich-text-advanced h5 a, .rich-text-advanced h6 a',
							'property'      => 'color',
						)
					),
					'heading_link_hover_color' => array(
						'type'          => 'color',
						'label'         => __( 'Heading Link Hover Color', 'fl-builder' ),
						'default'       => '',
						'show_remove'	=> true,
						'preview'         => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced h1 a:hover, .rich-text-advanced h2 a:hover, .rich-text-advanced h3 a:hover, .rich-text-advanced h4 a:hover, .rich-text-advanced h5 a:hover, .rich-text-advanced h6 a:hover',
							'property'      => 'color',
						)
					),
					'font_size_h1' => array(
						'type'          => 'unit',
						'label'         => __( 'H1 Font Size', 'fl-builder' ),
						'default'       => '',
						'description'	=> 'px',
						'preview'         => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced h1',
							'property'      => 'font-size',
							'unit'        	=> 'px',
							'preview'         => array(
								'type'          => 'css',
								'selector'      => '.rich-text-advanced h1',
								'property'      => 'font-size',
								'unit'        	=> 'px',
							)
						)
					),
					'font_size_h2' => array(
						'type'          => 'unit',
						'label'         => __( 'H2 Font Size', 'fl-builder' ),
						'default'       => '',
						'description'	=> 'px',
						'preview'         => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced h2',
							'property'      => 'font-size',
							'unit'        	=> 'px',
							'preview'         => array(
								'type'          => 'css',
								'selector'      => '.rich-text-advanced h2',
								'property'      => 'font-size',
								'unit'        	=> 'px',
							)
						)
					),
					'font_size_h3' => array(
						'type'          => 'unit',
						'label'         => __( 'H3 Font Size', 'fl-builder' ),
						'default'       => '',
						'description'	=> 'px',
						'preview'         => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced h3',
							'property'      => 'font-size',
							'unit'        	=> 'px',
							'preview'         => array(
								'type'          => 'css',
								'selector'      => '.rich-text-advanced h3',
								'property'      => 'font-size',
								'unit'        	=> 'px',
							)
						)
					),
					'font_size_h4' => array(
						'type'          => 'unit',
						'label'         => __( 'H4 Font Size', 'fl-builder' ),
						'default'       => '',
						'description'	=> 'px',
						'preview'         => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced h4',
							'property'      => 'font-size',
							'unit'        	=> 'px',
							'preview'         => array(
								'type'          => 'css',
								'selector'      => '.rich-text-advanced h4',
								'property'      => 'font-size',
								'unit'        	=> 'px',
							)
						)
					),
					'font_size_h5' => array(
						'type'          => 'unit',
						'label'         => __( 'H5 Font Size', 'fl-builder' ),
						'default'       => '',
						'description'	=> 'px',
						'preview'         => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced h5',
							'property'      => 'font-size',
							'unit'        	=> 'px',
							'preview'         => array(
								'type'          => 'css',
								'selector'      => '.rich-text-advanced h5',
								'property'      => 'font-size',
								'unit'        	=> 'px',
							)
						)
					),
					'font_size_h6' => array(
						'type'          => 'unit',
						'label'         => __( 'H6 Font Size', 'fl-builder' ),
						'default'       => '',
						'description'	=> 'px',
						'preview'         => array(
							'type'          => 'css',
							'selector'      => '.rich-text-advanced h6',
							'property'      => 'font-size',
							'unit'        	=> 'px',
							'preview'         => array(
								'type'          => 'css',
								'selector'      => '.rich-text-advanced h6',
								'property'      => 'font-size',
								'unit'        	=> 'px',
							)
						)
					),
				)
			),
			'mobile'         => array(
				'title'         => 'Mobile',
				'fields'        => array(
					'mobile_target_centered' => array(
						'type'          => 'select',
						'label'         => __( 'Align Centered on Mobile', 'fl-builder' ),
						'default'       => '',
						'options'       => array(
							''		=>  'No',
							' centered-mobile'		=>  'Yes',
						),
					),
				)
			),
		)
	)
));