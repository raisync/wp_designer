<?php if ( !empty($settings->font_family) && $settings->font_family['family'] != "Default" || $settings->font_size <> '' || !empty($settings->color) || $settings->font_weight <> '' ) { ?>
	.fl-node-<?php echo $id; ?> .rich-text-advanced *:not(i):not(h1):not(h2):not(h3):not(h4):not(h5):not(h6):not(a){ 
		<?php if ( !empty($settings->font_family) && $settings->font_family['family'] != "Default" ) { ?>
			<?php FLBuilderFonts::font_css( $settings->font_family ); ?>
		<?php } ?>
		<?php if ($settings->font_size <> '') { ?>
			font-size: <?php echo $settings->font_size; ?>px;
		<?php } ?>
		<?php if ($settings->font_weight <> '') { ?>
			font-weight: <?php echo $settings->font_weight; ?>;
		<?php } ?>
		<?php if ( !empty($settings->color) ) { ?>
			color: #<?php echo $settings->color; ?>;
		<?php } ?>
	}
<?php } ?>

<?php if ( !empty($settings->link_color) ) { ?>
	.fl-node-<?php echo $id; ?> .rich-text-advanced *:not(i):not(h1):not(h2):not(h3):not(h4):not(h5):not(h6) a{ 
		<?php if ( !empty($settings->link_color) ) { ?>
			color: #<?php echo $settings->link_color; ?>;
		<?php } ?>
	}
<?php } ?>

<?php if ( !empty($settings->link_hover_color) ) { ?>
	.fl-node-<?php echo $id; ?> .rich-text-advanced *:not(i):not(h1):not(h2):not(h3):not(h4):not(h5):not(h6) a:hover{ 
		<?php if ( !empty($settings->link_hover_color) ) { ?>
			color: #<?php echo $settings->link_hover_color; ?>;
		<?php } ?>
	}
<?php } ?>

<?php if ( !empty($settings->font_family_heading) && $settings->font_family_heading['family'] != "Default" || $settings->font_size <> '' || !empty($settings->heading_color) ) { ?>
	.fl-node-<?php echo $id; ?> .rich-text-advanced h1, .rich-text-advanced h2, .rich-text-advanced h3, .rich-text-advanced h4, .rich-text-advanced h5, .rich-text-advanced h6{ 
		<?php if ( !empty($settings->font_family_heading) && $settings->font_family_heading['family'] != "Default" ) { ?>
			<?php FLBuilderFonts::font_css( $settings->font_family_heading ); ?>
		<?php } ?>
		<?php if ($settings->font_size <> '') { ?>
			font-size: <?php echo $settings->font_size; ?>px;
		<?php } ?>
		<?php if ( !empty($settings->heading_color) ) { ?>
			color: #<?php echo $settings->heading_color; ?>;
		<?php } ?>
	}
<?php } ?>

<?php if ( !empty($settings->heading_link_color) ) { ?>
	.fl-node-<?php echo $id; ?> .rich-text-advanced h1 a, .rich-text-advanced h2 a, .rich-text-advanced h3 a, .rich-text-advanced h4 a, .rich-text-advanced h5 a, .rich-text-advanced h6 a{ 
		<?php if ( !empty($settings->heading_link_color) ) { ?>
			color: #<?php echo $settings->heading_link_color; ?>;
		<?php } ?>
	}
<?php } ?>

<?php if ( !empty($settings->heading_link_hover_color) ) { ?>
	.fl-node-<?php echo $id; ?> .rich-text-advanced h1 a:hover, .rich-text-advanced h2 a:hover, .rich-text-advanced h3 a:hover, .rich-text-advanced h4 a:hover, .rich-text-advanced h5 a:hover, .rich-text-advanced h6 a:hover{ 
		<?php if ( !empty($settings->heading_link_hover_color) ) { ?>
			color: #<?php echo $settings->heading_link_hover_color; ?>;
		<?php } ?>
	}
<?php } ?>

<?php if ( $settings->font_size_h1 <> '' ) { ?>
	.fl-node-<?php echo $id; ?> .rich-text-advanced h1{ 
		font-size: <?php echo $settings->font_size_h1; ?>px;
	}
<?php } ?>

<?php if ( $settings->font_size_h2 <> '' ) { ?>
	.fl-node-<?php echo $id; ?> .rich-text-advanced h2{ 
		font-size: <?php echo $settings->font_size_h2; ?>px;
	}
<?php } ?>

<?php if ( $settings->font_size_h3 <> '' ) { ?>
	.fl-node-<?php echo $id; ?> .rich-text-advanced h3{ 
		font-size: <?php echo $settings->font_size_h3; ?>px;
	}
<?php } ?>

<?php if ( $settings->font_size_h4 <> '' ) { ?>
	.fl-node-<?php echo $id; ?> .rich-text-advanced h4{ 
		font-size: <?php echo $settings->font_size_h4; ?>px;
	}
<?php } ?>

<?php if ( $settings->font_size_h5 <> '' ) { ?>
	.fl-node-<?php echo $id; ?> .rich-text-advanced h5{ 
		font-size: <?php echo $settings->font_size_h5; ?>px;
	}
<?php } ?>

<?php if ( $settings->font_size_h6 <> '' ) { ?>
	.fl-node-<?php echo $id; ?> .rich-text-advanced h6{ 
		font-size: <?php echo $settings->font_size_h6; ?>px;
	}
<?php } ?>