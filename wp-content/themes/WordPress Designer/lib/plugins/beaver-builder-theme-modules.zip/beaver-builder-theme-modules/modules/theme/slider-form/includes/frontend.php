<?php	
$output = '<div class="'.$module->get_classname().'">';
	$output .= '<div class="owl-carousel '.$settings->loop_animation.'">';
		for($i = 0; $i < count($settings->items); $i++) : if(!is_object($settings->items[$i])) continue;
			$output .= '<div class="slide-item slide-'.($i+1).' '.$settings->items[$i]->slider_style.'">';
					$output .= '<div class="fl-row-fixed-width">';
						$output .= '<div class="slider-info">';
							$output .='<div class="slider-info-content">';
								if ( !empty( $settings->items[$i]->slider_title ) ) {
									$output .='<h2 class="slider-title">'.$settings->items[$i]->slider_title.'</h2>';
								}
								if ( !empty( $settings->items[$i]->slider_text ) ) {
									$output .='<p class="slider-text">';
										$output .= nl2br($settings->items[$i]->slider_text);
									$output .='</p>';
								}
							$output .='</div>';
						$output .= '</div>';
					$output .= '</div>';
			$output .= '</div>';
		endfor;
	$output .= '</div>';

	$output .= '<div class="slider-form-wrapper">';
		$output .= '<div class="fl-row-fixed-width">';
			$output .= '<div class="slider-form-wrapper-inner">';
				$output .= $settings->form;
				$output .= '<p class="form-note heading-font">Your privacy is important to us.<br> we will never share your information</p>';
			$output .= '</div>';
		$output .= '</div>';
	$output .= '</div>';
	
$output .= '</div>';
echo $output;
?>