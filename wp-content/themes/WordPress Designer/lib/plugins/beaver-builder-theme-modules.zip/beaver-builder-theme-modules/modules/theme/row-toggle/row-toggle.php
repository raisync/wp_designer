<?php

/**
 * @class RowToggleModule
 */
class RowToggleModule extends FLBuilderModule {

	/**
	 * @method __construct
	 */
	public function __construct()
	{
		global $foldercategory;
		parent::__construct(array(
			'name'          	=> __('Row Toggle', 'fl-builder'),
			'description'   	=> __('Row Toggle.', 'fl-builder'),
			'category'      	=> __($foldercategory, 'fl-builder'),
            'editor_export' 	=> false,
			'partial_refresh'	=> true
		));
	}

	/**
	 * @method get_classname
	 */
	public function get_classname()
	{
		$classname = 'row-toggle';
		return $classname;
	}
}

/**
 * Register the module and its form settings.
 */
FLBuilder::register_module('RowToggleModule', array(
	'general'       => array(
		'title'         => __('General', 'fl-builder'),
		'sections'      => array(
			'general'         => array(
				'title'         => '',
				'fields'        => array(
					'row_toggle_text' => array(
						'type'          => 'text',
						'label'         => __('Title', 'fl-builder'),
						'default'       => 'LEARN MORE ABOUT PRODUCT FEATURES',
						'placeholder'       => 'LEARN MORE ABOUT PRODUCT FEATURES',
					),
					'row_toggle_color' => array(
						'type'          => 'color',
						'label'         => __('Title Color', 'fl-builder'),
						'show_reset'       => true,
						'preview'       => array(
							'type'          => 'css',
							'selector'      => '.toggle-row-title',
							'property'      => 'color',
						)
					),
					'row_toggle_size' => array(
						'type'          => 'unit',
						'label'         => __('Title Size', 'fl-builder'),
						'default'          => '',
						'placeholder'          => '24',
						'description'          => 'px',
						'preview'       => array(
							'type'          => 'css',
							'selector'      => '.toggle-row-button',
							'property'      => 'font-size',
							'unit'      => 'px',
						),
						'responsive'  => array(
							'placeholder' => array(
								'default'    => ( isset( $global_settings->row_toggle_size ) ) ? $global_settings->row_toggle_size : '24',
								'medium'     => ( isset( $global_settings->row_toggle_size_medium ) ) ? $global_settings->row_toggle_size_medium : '',
								'responsive' => ( isset( $global_settings->row_toggle_size_responsive ) ) ? $global_settings->row_toggle_size_responsive : '',
							)
						),
					),
				)
			)
		),
	),
));