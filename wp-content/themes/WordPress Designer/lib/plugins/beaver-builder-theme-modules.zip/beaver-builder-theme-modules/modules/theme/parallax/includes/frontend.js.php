(function($) {
	$(function() {
		parallax = skrollr.init({
			forceHeight: false,
			<?php if ( $settings->smoothscrolling == 'true' ) { ?>
				smoothScrolling: true,
			<?php } else if ( $settings->smoothscrolling == 'custom' && isset($settings->smoothscrolling_custom) ) { ?>
				smoothScrollingDuration: <?php echo $settings->smoothscrolling_custom; ?>,
			<?php } else { ?>
				smoothScrolling: false,
			<?php } ?>
			render: function(data) {
				//Log the current scroll position.
				console.log(data.curTop);
			}
		});
	
		setTimeout(function(){
			parallax.refresh();
			$('.parallax').each( function(){
				$(this).closest('.fl-col-group:first-child').addClass('parallax-wrapper').parent().addClass('parallax-wrapper-outer').closest('.fl-row-content-wrap').addClass('parallax-wrapper-row');
			});
			if (parallax.isMobile()) {
				parallax.destroy();
			}
		}, 1000);
	
		function parallax_rewrapped() {
			parallax.refresh();
			$('.parallax').closest('.fl-row-content-wrap').removeClass('parallax-wrapper-row')
			$('.parallax').closest('.fl-row-content').removeClass('parallax-wrapper-outer')
			$('.parallax').closest('.fl-col-group').removeClass('parallax-wrapper');
			setTimeout(function(){
				parallax.refresh();
				$(this).closest('.fl-col-group:first-child').addClass('parallax-wrapper').parent().addClass('parallax-wrapper-outer').closest('.fl-row-content-wrap').addClass('parallax-wrapper-row');
				if (parallax.isMobile()) {
					parallax.destroy();
				}
			}, 500);
		}
		$( '.fl-builder-content' ).on( 'fl-builder.layout-rendered', parallax_rewrapped() );
		$( '.fl-builder-content' ).on( 'fl-builder.preview-rendered', parallax_rewrapped() );

		$('.toggle-row-button').on('click', '.togglable', function(){
			setTimeout(function(){
				parallax.refresh();
			}, 1000);
		});
		$('.fl-builder-bar-actions').on('click', '.fl-builder-hover-content-button', function(){
			setTimeout(function(){
				parallax.refresh();
			}, 1000);
		});
	});
})(jQuery);