(function($) {
	$(function() {
		
		function contentResizer() {
			var windowW = $(window).width(),
				gridderW = $('.portfolio-gridder').width(),
				left = (windowW - gridderW)/2;
				$('.gridder-show').css('width', windowW+'px');
				$('.gridder-show').css('left', '-'+left+'px');
		}
		var $scrollOffset;
		if ($('.admin-bar').length ) {
			$scrollOffset = 120;
		} else {
			$scrollOffset = 90;
		}
		$('.fl-node-<?php echo $id; ?> .gridder').gridderExpander({
			scroll: true,
			scrollOffset: $scrollOffset,
			scrollTo: "listitem",                  // panel or listitem
			animationSpeed: 400,
			animationEasing: "easeInOutExpo",
			showNav: false,                      // Show Navigation
			nextText: "<i class=\"fa fa-arrow-right\"></i>",                   // Next button text
			prevText: "<i class=\"fa fa-arrow-left\"></i>",               // Previous button text
			closeText: "<i class=\"fa fa-times\"></i>",                 // Close button text
			onStart: function(){
				//Gridder Inititialized
			},
			onContent: function(){
				//Gridder Content Loaded
				if ($('.fl-builder-bar-actions').length ) {
					$('.fl-builder-hover-content-button').click();
				}
				contentResizer();
				
				$('.gridder-list').removeClass('loaded');
				setTimeout(function(){
					$('.selectedItem').addClass('loaded');
				}, 1);
				$('.gridder-expanded-content #content').prevAll(':not([id*="fl-builder-layout"]):not([id*="fl-builder-google-fonts"])').remove();
				$('.gridder-expanded-content #content').nextAll().remove();
				
			},
			onClosed: function(){
				//Gridder Closed
				$('.gridder-list').removeClass('loaded');
			}
		});
		
		$('.gridder-list').click( function() {
			setTimeout(function(){
				contentResizer();
			}, 10);
		});
		var $window = $(window);
		$window.resize(function resize() {
			contentResizer();
		}).trigger('resize');
		
		/*first-word*/
        $('.gridder-button .title').each(function(){
			var me = $(this),
				special = $(this).text();
			if ( special.indexOf("/") > -1 ) {
				$(this).wrapInner('<span />');
			} else {
				me.html(me.html().replace(/^(\w+)/, '<span>$1</span>'));
			}
		});
		
		
		$('.gridder .gridder-list').hover( function() {
			$(this).parent().addClass('hovered');
		  }, function() {
			$(this).parent().removeClass('hovered');
		  }
		);

	});
})(jQuery);