<?php if ( !empty($settings->max_width) ) { ?>
	.fl-node-<?php echo $id; ?> .benefits{
		max-width: <?php echo $settings->max_width; ?>px;
		margin-left: auto;
		margin-right: auto;
	}
<?php } ?>
<?php 
	global $_wp_additional_image_sizes;
	$imageheight = $_wp_additional_image_sizes[$settings->image_size]['height'];
	if ( $settings->image_size != 'benefits-photo' ) {
?>
	.fl-node-<?php echo $id; ?> .benefits-image { padding-top: <?php echo $imageheight; ?>px; }
<?php } ?>
<?php if ( $settings->column_spacing <> '' ) { ?>
	.fl-node-<?php echo $id; ?> .benefits-items { padding-right: <?php echo $settings->column_spacing; ?>px; margin-left: -<?php echo $settings->column_spacing; ?>px; width: calc(100% + <?php echo $settings->column_spacing; ?>px + <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(100% + <?php echo $settings->column_spacing; ?>px + <?php echo $settings->column_spacing; ?>px); }
	.fl-node-<?php echo $id; ?> .benefits-item { margin: 0 0 <?php echo $settings->column_spacing; ?>px <?php echo $settings->column_spacing; ?>px; }

	@media only screen and ( max-width: 1663px ) { 
		.fl-node-<?php echo $id; ?> .fl-row-content.fl-row-full-width .column-5 .benefits-item,
		.fl-node-<?php echo $id; ?> .fl-row-content.fl-row-full-width .column-6 .benefits-item { width: calc(25% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(25% - <?php echo $settings->column_spacing; ?>px); } 
	}
	@media only screen and ( max-width: 1080px ) { 
		.fl-node-<?php echo $id; ?> .column-5 .benefits-item,
		.fl-node-<?php echo $id; ?> .column-6 .benefits-item { width: calc(25% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(25% - <?php echo $settings->column_spacing; ?>px); } 
	}
	@media only screen and ( min-width: 1024px ) { 
		.fl-node-<?php echo $id; ?> .column-1 .benefits-item { width: calc(100% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(100% - <?php echo $settings->column_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .column-2 .benefits-item { width: calc(50% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(50% - <?php echo $settings->column_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .column-3 .benefits-item { width: calc(33.33% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(33.33% - <?php echo $settings->column_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .column-4 .benefits-item { width: calc(25% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(25% - <?php echo $settings->column_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .column-5 .benefits-item {  width: calc(20% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(20% - <?php echo $settings->column_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .column-6 .benefits-item { width: calc(16.666% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(16.666% - <?php echo $settings->column_spacing; ?>px); }
	}
	@media only screen and ( max-width: 1023px ) { 
		.fl-node-<?php echo $id; ?> .column-1 .benefits-item { width: calc(100% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(100% - <?php echo $settings->column_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .column-2 .benefits-item { width: calc(50% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(50% - <?php echo $settings->column_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .column-3 .benefits-item { width: calc(33.33% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(33.33% - <?php echo $settings->column_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .column-4 .benefits-item { width: calc(25% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(25% - <?php echo $settings->column_spacing; ?>px); }
		.fl-node-<?php echo $id; ?> .column-5 .benefits-item,
		.fl-node-<?php echo $id; ?> .column-6 .benefits-item { width: calc(33.33% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(33.33% - <?php echo $settings->column_spacing; ?>px); } 
	}
	@media only screen and ( max-width: 767px ) { 
		.fl-node-<?php echo $id; ?> .column-1 .benefits-item,
		.fl-node-<?php echo $id; ?> .column-2 .benefits-item { width: calc(100% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(100% - <?php echo $settings->column_spacing; ?>px); } 
		.fl-node-<?php echo $id; ?> .column-3 .benefits-item,
		.fl-node-<?php echo $id; ?> .column-4 .benefits-item { width: calc(50% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(50% - <?php echo $settings->column_spacing; ?>px); } 
		.fl-node-<?php echo $id; ?> .column-5 .benefits-item,
		.fl-node-<?php echo $id; ?> .column-6 .benefits-item { width: calc(33.33% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(33.33% - <?php echo $settings->column_spacing; ?>px); } 
	}
	@media only screen and ( max-width: 530px ) { 
		.fl-node-<?php echo $id; ?> .column-1 .benefits-item,
		.fl-node-<?php echo $id; ?> .column-2 .benefits-item,
		.fl-node-<?php echo $id; ?> .column-3 .benefits-item,
		.fl-node-<?php echo $id; ?> .column-4 .benefits-item,
		.fl-node-<?php echo $id; ?> .column-5 .benefits-item,
		.fl-node-<?php echo $id; ?> .column-6 .benefits-item { width: calc(100% - <?php echo $settings->column_spacing; ?>px); width: -webkit-calc(100% - <?php echo $settings->column_spacing; ?>px); } 
	}
<?php } ?>