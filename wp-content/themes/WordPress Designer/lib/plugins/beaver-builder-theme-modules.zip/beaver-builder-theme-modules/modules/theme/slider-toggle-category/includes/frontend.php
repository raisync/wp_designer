<?php	
$output = '<div class="'.$module->get_classname().'">';
	$output .= '<div class="owl-carousel slides '.$settings->loop_animation.'">';
		for($i = 0; $i < count($settings->items); $i++) : if(!is_object($settings->items[$i])) continue;
			$output .= '<div class="slide-item slide-'.($i+1).' '.$settings->items[$i]->slider_style.'">';
					$output .= '<div class="fl-row-fixed-width">';
						$output .= '<div class="slider-info">';
							$output .='<div class="slider-info-content">';
								if ( !empty( $settings->items[$i]->slider_title ) ) {
									$output .='<h2 class="slider-title">'.$settings->items[$i]->slider_title.'</h2>';
								}
								if ( !empty( $settings->items[$i]->slider_text ) ) {
									$output .='<p class="slider-text">';
										$output .= nl2br($settings->items[$i]->slider_text);
									$output .='</p>';
								}
							$output .='</div>';
						$output .= '</div>';
					$output .= '</div>';
			$output .= '</div>';
		endfor;
	$output .= '</div>';

	$output .= '<div class="slider-toggles-button">';
		$output .= '<div class="fl-row-fixed-width">';
			$output .= '<div class="owl-carousel slider-toggles-button-wrapper">';
				for($i = 0; $i < count($settings->toggles_item); $i++) : if(!is_object($settings->toggles_item[$i])) continue;
				$productCategory = get_term_by( 'id', $settings->toggles_item[$i]->toggles_item_page, 'case_category' );
				$output .= '
					<figure class="slider-toggles-item item-'.($i+1).' item-page-'.$settings->toggles_item[$i]->toggles_item_page.'">';
						
						if ( empty($settings->toggles_item[$i]->toggles_item_image) ) {
							if ( !empty($settings->toggles_item[$i]->toggles_item_page) ) {
								$thumb_src = get_field('featured_image', 'case_category_'.$settings->toggles_item[$i]->toggles_item_page );
								$thumb_src = $thumb_src['sizes'][ 'slider-toggle-thumb' ];
								$thumb_src = $thumb_src <> '' ? $thumb_src : $module->url.'/images/thumb.jpg';
								$output .= '<img src="'.$thumb_src.'" alt="'.$productCategory->name.' thumb">';
								
							}
						} else {
							$thumb = '';
							$thumb = FLBuilderPhoto::get_attachment_data($settings->toggles_item[$i]->toggles_item_image);
							$thumb_alt = ($thumb->alt <> '') ? $thumb->alt : $thumb->title;
							$thumb_title = ($thumb->title <> '') ? $thumb->title : $thumb->alt;
							$thumb_src = wp_get_attachment_image_src($thumb->id, 'slider-toggle-thumb');
							$output .= '<img src="'.$thumb_src[0].'" alt="'.$thumb_alt.'">';
						}
						$output .= '<figcaption>';
							if ( empty($settings->toggles_item[$i]->toggles_item_title) ) {
									$output .= '<h3>'.$productCategory->name.'</h3>';							
							} else {
								$output .= '<h3>'.$settings->toggles_item[$i]->toggles_item_title.'</h3>';
							}
							$output .= '<i class="fa fa-angle-right" aria-hidden="true"></i>';
						$output .= '</figcaption>
					</figure>';
				endfor;
			$output .= '</div>';
		$output .= '</div>';
	$output .= '</div>';

	$output .= '<div class="slider-toggles-content">';
		$output .= '<div class="fl-row-fixed-width">';
			$output .= '<div class="slider-toggles-content-wrapper">';
				for($i = 0; $i < count($settings->toggles_item); $i++) : if(!is_object($settings->toggles_item[$i])) continue;
				$productCategory = get_term_by( 'id', $settings->toggles_item[$i]->toggles_item_page, 'case_category' );
				$output .= '
					<div class="slider-toggles-content-item item-'.($i+1).'">';
						if ( !empty($settings->toggles_item[$i]->toggles_item_page) ) {
								if ( empty($settings->toggles_item[$i]->toggles_item_image) ) {
									$image_src = get_field('featured_image', 'case_category_'.$settings->toggles_item[$i]->toggles_item_page );
									$image_src = $image_src['sizes'][ 'slider-toggle-content-images' ];
									$image_src = $image_src <> '' ? $image_src : $module->url.'/images/large.jpg';
									$image_src = $image_src;
								} else {
									$image = '';
									$image = FLBuilderPhoto::get_attachment_data($settings->toggles_item[$i]->toggles_item_image);
									$image_src = wp_get_attachment_image_src($image->id, 'slider-toggle-content-images')['0'];
									
								}
								if ( empty($settings->toggles_item[$i]->toggles_item_title) ) {
									$content_title = $productCategory->name;
								} else {
									$content_title = $settings->toggles_item[$i]->toggles_item_title;
								}
								$data_title = $settings->toggles_item[$i]->toggles_item_table_title ? $settings->toggles_item[$i]->toggles_item_table_title : 'Data From The Past 30 Days';
								$data_col_1 = $settings->toggles_item[$i]->toggles_item_table_col_1_title <> '' ? $settings->toggles_item[$i]->toggles_item_table_col_1_title : 'Drinks Poured';
								$data_col_2 = $settings->toggles_item[$i]->toggles_item_table_col_2_title <> '' ? $settings->toggles_item[$i]->toggles_item_table_col_2_title : 'Total Revenue';
								$data_col_3 = $settings->toggles_item[$i]->toggles_item_table_col_3_title <> '' ? $settings->toggles_item[$i]->toggles_item_table_col_3_title : 'Active Taps';
								$data_col_1_value = get_field('drinks_poured', 'case_category_'.$settings->toggles_item[$i]->toggles_item_page) <> '' ? get_field('drinks_poured', 'case_category_'.$settings->toggles_item[$i]->toggles_item_page) : '0';
								$data_col_2_value = get_field('total_revenue', 'case_category_'.$settings->toggles_item[$i]->toggles_item_page) <> '' ? get_field('total_revenue', 'case_category_'.$settings->toggles_item[$i]->toggles_item_page) : '0';
								$data_col_3_value = get_field('active_taps', 'case_category_'.$settings->toggles_item[$i]->toggles_item_page) <> '' ? get_field('active_taps', 'case_category_'.$settings->toggles_item[$i]->toggles_item_page) : '0';
								$output .= '
								<figure class="slider-toggles-content-image">
									<img src="'.$image_src.'" alt="'.$productCategory->name.' - Featured Image">
								</figure>
								<div class="slider-toggles-content-text">
									<h3 class="title">'.$content_title.'</h3>
									<section class="desc" data-scrollbar>'.$productCategory->description.'</section>
									<h4 class="data-title">'.$data_title.'</h4>
									<div class="data-table">
										<div class="data-row">
											<div class="data-cell">
												<h4>'.$data_col_1.'</h4>
												<p>'.number_format($data_col_1_value).' vol</p>
											</div>	
											<div class="data-cell">
												<h4>'.$data_col_2.'</h4>
												<p>$ '.number_format($data_col_2_value).'</p>
											</div>
											<div class="data-cell">
												<h4>'.$data_col_3.'</h4>
												<p>'.number_format($data_col_3_value).'</p>
											</div>
										</div>
									</div>
								</div>';
						}
						$output .= '<div class="slider-toggles-content-testimonial">';
							$query_args = array(
								'post_type' => 'testimonial',
								'posts_per_page' => 1,
								'orderby' => $settings->toggles_item[$i]->testimonial_orderby,
								'order' => $settings->toggles_item[$i]->testimonial_order,
								'tax_query' => array( 
									array( 
										'taxonomy' => 'testimonial_category', //or tag or custom taxonomy
										'field' => 'slug', 
										'terms' => $settings->toggles_item[$i]->testimonial_categories
									) 
								)
							);
							$query = new WP_Query($query_args);
							while ($query->have_posts()) : $query->the_post(); 
								$photo = wp_get_attachment_image_src( get_post_thumbnail_id( $query->ID ), $settings->image_size );
								$photoURL = $photo[0] ? $photo[0] : $module->url.'/images/avatar.png';
								$output .= '
								<blockqoute class="slider-toggles-testimonial">
									<div class="message"><div class="message-container" data-scrollbar>'.get_the_content().'</div></div>
									<figure class="avatar">
										<img src="'.$photoURL.'" alt="'.get_the_title().' Avatar">
										<figcaption>
											<h5 class="name">'.get_the_title().'</h5>
											<div class="position">'.get_field('company').'</div>
										</figcaption>
									</figure>
								</blockqoute>'; 
							endwhile; wp_reset_query();
							if ( !empty($settings->toggles_item[$i]->toggles_item_page) ) {
								$readmore = $settings->toggles_item[$i]->toggles_item_read_more <> '' ? $settings->toggles_item[$i]->toggles_item_read_more : 'READ MORE';
								$output .= '<a class="btn-0 btn btn-icon icon-after btn-default  btn-md btn-curved" href="'.get_term_link($productCategory).'" target="_self" role="button"><span>'.$readmore.'</span><i class="fa fa-angle-double-right"></i></a>';
							}
						$output .= '</div>
					</div>';
				endfor;
			$output .= '</div>';
		$output .= '</div>';
	$output .= '</div>';
	
$output .= '</div>';
echo $output;
?>