<?php // Row width limit
	$global_settings = FLBuilderModel::get_global_settings(); 
	$row_width = $global_settings->row_width + 120; 
?>
@media only screen and ( max-width: <?php echo $row_width; ?>px ) and ( min-width: 1170px ) { 
	.partners-logo { padding: 0 80px; }
}