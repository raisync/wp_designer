<?php if ( !empty($settings->iconbox_bg_color) ) { ?>
	.fl-node-<?php echo $id; ?> .icon-box-toggle{ 
		background-color: #<?php echo $settings->iconbox_bg_color; ?>;
	}
<?php } ?>