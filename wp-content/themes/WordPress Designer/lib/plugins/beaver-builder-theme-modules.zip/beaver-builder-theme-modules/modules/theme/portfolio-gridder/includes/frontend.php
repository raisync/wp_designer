<div class="<?php echo $module->get_classname(); ?>">
	<ul class="gridder <?php echo $settings->grid;?>">
		<?php global $post;
			if ( $settings->categories != 'selected' || $settings->selected_categories == '' ) {
				$query_args = array(
					'post_type' => 'portfolio',
					'posts_per_page' => $settings->totalpost,
					'orderby' => $settings->orderby,
					'order' => $settings->order,
					'offset' => $settings->offset,
				);
			} else {
				$query_args = array(
					'post_type' => 'portfolio',
					'posts_per_page' => $settings->totalpost,
					'orderby' => $settings->orderby,
					'order' => $settings->order,
					'offset' => $settings->offset,
					'tax_query' => array( 
						array( 
							'taxonomy' => 'portfolio_category', //or tag or custom taxonomy
							'field' => 'slug', 
							'terms' => $settings->selected_categories
						) 
					)
				);
			}
			$query = new WP_Query($query_args);
			while ($query->have_posts()) : $query->the_post(); 
		?>
			<li class="gridder-list" data-griddercontent="<?php the_permalink(); ?>">
				<?php $featuresThumb = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'portfolio-gridder-large' ); ?>
				<?php $featuresThumbURL = $featuresThumb[0];?>
				<?php if( ! empty($featuresThumbURL) ) { ?>
					<button class="gridder-button" type="button" style="background-image: url('<?php echo $featuresThumbURL; ?>');">
						<span class="title"><?php the_title(); ?></span>
					</button>
				<?php } ?>
			</li>
		<?php  endwhile; wp_reset_query(); ?>
	</ul>
</div>
