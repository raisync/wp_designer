<?php 
# Silence is golden.