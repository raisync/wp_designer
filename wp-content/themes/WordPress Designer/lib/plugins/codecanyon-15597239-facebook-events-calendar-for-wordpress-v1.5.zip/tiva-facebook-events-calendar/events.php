<?php
// Get params from config file
$fb_page_id = $_POST['page_id'];
$year_range = $_POST['year_range'];
$show_image = $_POST['show_image'];
$show_time = $_POST['show_time'];
$show_location = $_POST['show_location'];
$show_description = $_POST['show_description'];
$show_map = $_POST['show_map'];

// Set time to display events
$since_date = strtotime(date('Y-m-d', strtotime('-' . $year_range . ' years')));
$until_date = strtotime(date('Y-m-d', strtotime('+' . $year_range . ' years')));

// Request to Facebook Graph API to get events
$access_token = "226601451024177|1_YwHxuKJTfz4e8_6Sz-zGtUtpg";
$fields = "id,name,description,place,timezone,start_time,end_time,cover";
$json_link = "https://graph.facebook.com/{$fb_page_id}/events/attending/?fields={$fields}&access_token={$access_token}&since={$since_date}&until={$until_date}&limit=1000";
$json = file_get_contents($json_link);

// Decode json from Facebook Graph API
$fb_events = json_decode($json, true);

// Convert data for json to use in ajax
$events = array();
if (count($fb_events['data']) > 0) {
	foreach ($fb_events['data'] as $fb_event) {
		date_default_timezone_set($fb_event['timezone']);
		$event = new stdClass();
		$event->event_id = $fb_event['id'];
		$event->name = $fb_event['name'];
		
		if ($show_image) {
			$event->image = isset($fb_event['cover']['source']) ? $fb_event['cover']['source'] : "https://graph.facebook.com/{$fb_page_id}/picture?type=large";
		} else {
			$event->image = '';
		}
		
		$event->day = date('j', strtotime($fb_event['start_time']));
		$event->month = date('n', strtotime($fb_event['start_time']));
		$event->year = date('Y', strtotime($fb_event['start_time']));
		
		if ($show_time) {
			$event->time = $fb_event['start_time'] ? date('g:i a', strtotime($fb_event['start_time'])) : '';
			$event->end_time = isset($fb_event['end_time']) ? date('g:i a', strtotime($fb_event['end_time'])) : '';
		} else {
			$event->time = '';
			$event->end_time = '';
		}
		
		// Duration
		if (!isset($fb_event['end_time'])) {
			$event->duration = 1; // If end_time is blank -> event's duration = 1 (day).
		} else {
			if (date('Ymd', strtotime($fb_event['start_time'])) == date('Ymd', strtotime($fb_event['end_time']))) { // If start date and end date are same day -> event's duration = 1 (day).
				$event->duration = 1;
			} else {
				$start_day = date('Y-m-d', strtotime($fb_event['start_time']));
				$end_day = date('Y-m-d', strtotime($fb_event['end_time']));
				$event->duration = ceil(abs(strtotime($end_day) - strtotime($start_day)) / 86400) + 1; // Get event's duration = days between start date and end date.
			}
		}
		$event->end_date = isset($fb_event['end_time']) ? date('d-m-Y', strtotime($fb_event['end_time'])) : '';
		
		// Location
		if ($show_location) {
			$location_ar = array();
			if (isset($fb_event['place']['name'])) { array_push($location_ar, $fb_event['place']['name']); }
			if (isset($fb_event['place']['location']['city'])) { array_push($location_ar, $fb_event['place']['location']['city']); }
			if (isset($fb_event['place']['location']['country'])) { array_push($location_ar, $fb_event['place']['location']['country']); }
			if (isset($fb_event['place']['location']['zip'])) { array_push($location_ar, $fb_event['place']['location']['zip']); }
			$event->location = implode(", ", $location_ar);
		} else {
			$event->location = '';
		}
		
		// Map
		if ($show_map) {
			if (isset($fb_event['place']['location']['latitude'])) { $event->latitude = $fb_event['place']['location']['latitude']; }
			if (isset($fb_event['place']['location']['longitude'])) { $event->longitude = $fb_event['place']['location']['longitude']; }
		} else {
			$event->latitude = '';
			$event->longitude = '';
		}
		
		if ($show_description) {
			if (isset($fb_event['description'])) {
				$event->intro = $fb_event['description'];
				$event->description = nl2br($fb_event['description']);
			}
		} else {
			$event->intro = '';
			$event->description = '';
		}
		
		array_push($events, $event);
	}
}

echo json_encode($events);
?>