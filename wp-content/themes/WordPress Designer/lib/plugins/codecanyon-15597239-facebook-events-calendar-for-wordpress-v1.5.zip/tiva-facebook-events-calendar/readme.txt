=== Tiva Facebook Events Calendar ===
Contributors: TivaTheme
Tags: events calendar, facebook calendar, facebook events, facebook events calendar

Tiva Facebook Events Calendar will display all events from your facebook page on calendar. It can also display events via list view and detail of each event.