<?php
/*   
 Plugin Name: Tiva Facebook Events Calendar
 Plugin URI: 
 Description: Tiva Facebook Events Calendar will display all events from your facebook page on calendar. It can also display events via list view and detail of each event.
 Version: 1.4
 Author: TivaTheme
 Author URI: http://halobook.vn/demo                                                              
 */
 
// Include js file
function tiva_adding_scripts() {
	wp_register_script('js-calendar', plugins_url('assets/js/calendar.js', __FILE__), array('jquery'), '1.0', true);
	wp_enqueue_script('js-calendar');
}
add_action('wp_enqueue_scripts', 'tiva_adding_scripts');

// Include css file
function tiva_adding_css() {
	wp_register_style('css-font-awesome', plugins_url('assets/css/font-awesome.min.css', __FILE__));
	wp_enqueue_style('css-font-awesome');
	wp_register_style('css-calendar', plugins_url('assets/css/calendar.css', __FILE__));
	wp_enqueue_style('css-calendar');
	wp_register_style('css-calendar-full', plugins_url('assets/css/calendar_full.css', __FILE__));
	wp_enqueue_style('css-calendar-full');
	wp_register_style('css-calendar-compact', plugins_url('assets/css/calendar_compact.css', __FILE__));
	wp_enqueue_style('css-calendar-compact');
}
add_action('wp_enqueue_scripts', 'tiva_adding_css');

// Include color picker
function cal_color_picker(){
	wp_enqueue_script('wp-color-picker');
	wp_enqueue_style( 'wp-color-picker' );	
}
add_action( 'wp_print_scripts', 'cal_color_picker' );

function tiva_fb_events_calendar_custom_css($type, $id, $header_background, $header_color, $header_date_color, $btn_background, $btn_background_active, $btn_color, $today_background, $event_color_1, $event_color_2, $event_color_3, $event_color_4, $event_name, $event_info, $event_desc) {
	$calendar = '.tiva-events-calendar-wrapper' . '.' . $type . '-' . $id;
	?>
	<!-- Custom css -->
	<style>
	<?php if ($header_background != '#5aa4a3') { ?>
		<?php echo $calendar; ?> .tiva-calendar .calendar-title, <?php echo $calendar; ?> .tiva-calendar .calendar-btn {
			background: #<?php echo str_replace('#', '', $header_background); ?>;
		}
	<?php } ?>
	<?php if ($header_color != '#ffffff') { ?>
		<?php echo $calendar; ?> .tiva-calendar .calendar-title span, <?php echo $calendar; ?> .tiva-calendar .calendar-btn span {
			color: #<?php echo str_replace('#', '', $header_color); ?>;
		}
	<?php } ?>
	<?php if ($header_date_color != '#5aa4a3') { ?>
		<?php echo $calendar; ?> .tiva-calendar tr th {
			color: #<?php echo str_replace('#', '', $header_date_color); ?>;
		}
	<?php } ?>
	<?php if ($btn_background != '#757575') { ?>
		<?php echo $calendar; ?> .events-calendar-bar .bar-btn {
			background: #<?php echo str_replace('#', '', $btn_background); ?>;
		}
		<?php echo $calendar; ?> .tiva-event-tooltip .event-time {
			background: #<?php echo str_replace('#', '', $btn_background); ?>;
		}
		<?php echo $calendar; ?> .tiva-event-detail .event-link a {
			background: #<?php echo str_replace('#', '', $btn_background); ?>;
		}
	<?php } ?>
	<?php if ($btn_background_active != '#5aa4a3') { ?>
		<?php echo $calendar; ?> .events-calendar-bar .bar-btn.active, <?php echo $calendar; ?> .events-calendar-bar .bar-btn:hover {
			background: #<?php echo str_replace('#', '', $btn_background_active); ?> !important;	
		}
	<?php } ?>
	<?php if ($btn_color != '#ffffff') { ?>
		<?php echo $calendar; ?> .events-calendar-bar .bar-btn {
			color: #<?php echo str_replace('#', '', $btn_color); ?>;
		}
		<?php echo $calendar; ?> .tiva-event-tooltip .event-time {
			color: #<?php echo str_replace('#', '', $btn_color); ?>;
		}
		<?php echo $calendar; ?> .tiva-event-detail .event-link a {
			color: #<?php echo str_replace('#', '', $btn_color); ?>;
		}
	<?php } ?>
	<?php if ($today_background != '#d5e9e9') { ?>
		<?php echo $calendar; ?> .tiva-calendar .calendar-day-today {
			background: #<?php echo str_replace('#', '', $today_background); ?>;
		}
	<?php } ?>	
	<?php if ($event_color_1 != '#567bd2') { ?>
		<?php echo $calendar; ?> .tiva-calendar .calendar-event-name.color-1 {
			background: #<?php echo str_replace('#', '', $event_color_1); ?>;
		}
		<?php echo $calendar; ?> .tiva-calendar .calendar-event-mark::after {
			border-top: 16px solid #<?php echo str_replace('#', '', $event_color_1); ?>;
		}
	<?php } ?>
	<?php if ($event_color_2 != '#13baff') { ?>
		<?php echo $calendar; ?> .tiva-calendar .calendar-event-name.color-2 {
			background: #<?php echo str_replace('#', '', $event_color_2); ?>;
		}
	<?php } ?>
	<?php if ($event_color_3 != '#669933') { ?>
		<?php echo $calendar; ?> .tiva-calendar .calendar-event-name.color-3 {
			background: #<?php echo str_replace('#', '', $event_color_3); ?>;
		}
	<?php } ?>
	<?php if ($event_color_4 != '#ff8a23') { ?>
		<?php echo $calendar; ?> .tiva-calendar .calendar-event-name.color-4 {
			background: #<?php echo str_replace('#', '', $event_color_4); ?>;
		}
	<?php } ?>
	<?php if ($event_name != '#5aa4a3') { ?>
		<?php echo $calendar; ?> .tiva-event-tooltip .event-name,
		<?php echo $calendar; ?> .tiva-event-list .event-name,
		<?php echo $calendar; ?> .tiva-event-detail .event-name {
			color: #<?php echo str_replace('#', '', $event_name); ?>;
		}
	<?php } ?>
	<?php if ($event_info != '#de935f') { ?>
		<?php echo $calendar; ?> .tiva-event-list .event-time, 
		<?php echo $calendar; ?> .tiva-event-list .event-date,
		<?php echo $calendar; ?> .tiva-event-detail .event-time, 
		<?php echo $calendar; ?> .tiva-event-detail .event-date, 
		<?php echo $calendar; ?> .tiva-event-detail .event-location {
			color: #<?php echo str_replace('#', '', $event_info); ?>;
		}
	<?php } ?>
	<?php if ($event_desc != '#666666') { ?>
		<?php echo $calendar; ?> .tiva-event-tooltip .event-desc,
		<?php echo $calendar; ?> .tiva-event-list .event-desc,
		<?php echo $calendar; ?> .tiva-event-detail .event-desc {
			color: #<?php echo str_replace('#', '', $event_desc); ?>;
		}
	<?php } ?>
	</style>
	<?php
}

class TIVA_FACEBOOK_EVENTS_CALENDAR extends WP_Widget {
	public $tiva_fb_events_widget = 1;
	
	function __construct() {                                                                             
		parent::__construct(                                                                                                                                                                           
			'tiva_facebook_events_calendar', // Base ID                       
			__( 'Tiva Facebook Events Calendar', 'tiva-facebook-events-calendar' ), // Name
			array( 'description' => __( 'Display all events from your facebook page on calendar', 'tiva-facebook-events-calendar' ), ) // Args
		);
	}                      
	                                                                 
	public function form( $instance ) {
		$defaults = array(
			'title' => 'Facebook Events Calendar',
			'layout' => 'full',
			'page_id' => 'CelebrityTheatre',
			'year_range' => '1',
			'initial_view' => 'calendar',
			'switch_button' => 'show',
			'start_date' => 'sunday',
			'max_events' => '1000',
			'header_background' => '#5aa4a3',
			'header_color' => '#ffffff',
			'header_date_color' => '#5aa4a3',
			'btn_view_background' => '#757575',
			'btn_view_background_hover' => '#5aa4a3',
			'btn_view_color' => '#ffffff',
			'today_background' => '#d5e9e9',
			'event_color_1' => '#567bd2',
			'event_color_2' => '#13baff',
			'event_color_3' => '#669933',
			'event_color_4' => '#ff8a23',
			'event_name' => '#5aa4a3',
			'event_info' => '#de935f',
			'event_desc' => '#666666',
			'show_image' => '1',
			'show_time' => '1',
			'show_location' => '1',
			'show_description' => '1',
			'show_button' => '1',
			'show_map' => '1',
		);
		$instance = wp_parse_args((array)$instance, $defaults);
        ?>
		
		<?php if (version_compare(get_bloginfo('version'), '3.5') >= 0) { ?>
			<script>
			jQuery(document).ready(function() {
				jQuery('.color_input').wpColorPicker();
			});
			</script>
		<?php } ?>
		
		<style>
		.color_input.wp-color-picker{
			height: 23px;
			width: 80px;
		}
		.wp-picker-holder{
			top: -10px;
			<?php if (version_compare(get_bloginfo('version'), '4.0') < 0) { ?>
			right: 145px;
			top: -42px;
			<?php } ?>
			position: relative;
			z-index: 3;
		}
		.wp-color-result{
			background-color: transparent;
			left: -6px;
			top: 0 !important;
		}
		.wp-color-result:after{
			width: 73px;
		}
		.color_for_this{
			height: 24px;
			top: 0px;
			position: relative;
			width: 35px;
			left: 2px;
		}
		</style>
	
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title' ); ?>:</label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>"
                   name="<?php echo $this->get_field_name( 'title' ); ?>" type="text"
                   value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'layout' ); ?>"><?php _e( 'Layout' ); ?>:</label>
			<select class="widefat" name="<?php echo $this->get_field_name( 'layout' ); ?>">
				<option <?php if ($instance['layout'] == "full") echo 'selected="selected"'; ?> value="full">Full</option>
				<option <?php if ($instance['layout'] == "compact") echo 'selected="selected"'; ?> value="compact">Compact</option>
			</select>
        </p>
 
        <p>
            <label for="<?php echo $this->get_field_id( 'page_id' ); ?>"><?php _e( 'Facebook Page Id' ); ?>:</label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'page_id' ); ?>"
                   name="<?php echo $this->get_field_name( 'page_id' ); ?>" type="text"
                   value="<?php echo esc_attr( $instance['page_id'] ); ?>">
        </p>
 
        <p>
            <label for="<?php echo $this->get_field_id( 'year_range' ); ?>"><?php _e( 'Year Range' ); ?>:</label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'year_range' ); ?>"
                   name="<?php echo $this->get_field_name( 'year_range' ); ?>" type="text"
                   value="<?php echo esc_attr( $instance['year_range'] ); ?>">
        </p>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'initial_view' ); ?>"><?php _e( 'Initial View' ); ?>:</label>
			<select class="widefat" name="<?php echo $this->get_field_name( 'initial_view' ); ?>">
				<option <?php if ($instance['initial_view'] == "calendar") echo 'selected="selected"'; ?> value="calendar">Calendar</option>
				<option <?php if ($instance['initial_view'] == "list") echo 'selected="selected"'; ?> value="list">Event List</option>
			</select>
        </p>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'switch_button' ); ?>"><?php _e( 'Switch Calendar/List Button' ); ?>:</label>
			<select class="widefat" name="<?php echo $this->get_field_name( 'switch_button' ); ?>">
				<option <?php if ($instance['switch_button'] == "show") echo 'selected="selected"'; ?> value="show">Show</option>
				<option <?php if ($instance['switch_button'] == "hide") echo 'selected="selected"'; ?> value="hide">Hide</option>
			</select>
        </p>
		
		<p>
			<label for="<?php echo $this->get_field_id( 'start_date' ); ?>"><?php _e( 'Start Date' ); ?>:</label>
			<select class="widefat" name="<?php echo $this->get_field_name( 'start_date' ); ?>">
				<option <?php if ($instance['start_date'] == "sunday") echo 'selected="selected"'; ?> value="sunday">Sunday</option>
				<option <?php if ($instance['start_date'] == "monday") echo 'selected="selected"'; ?> value="monday">Monday</option>
			</select>
        </p>
		
		<p style="margin-bottom:25px;">
            <label for="<?php echo $this->get_field_id( 'max_events' ); ?>"><?php _e( 'Max events on list' ); ?>:</label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'max_events' ); ?>"
                   name="<?php echo $this->get_field_name( 'max_events' ); ?>" type="text"
                   value="<?php echo esc_attr( $instance['max_events'] ); ?>">
        </p>
		
		<hr>
		
		<table style="margin:15px 0 20px 0;">
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'header_background' ); ?>"><?php _e( 'Header Background' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['header_background']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('header_background'); ?>" name="<?php echo $this->get_field_name('header_background'); ?>" value="<?php echo $instance['header_background'];?>" />
					</div>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'header_color' ); ?>"><?php _e( 'Header Text Color' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['header_color']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('header_color'); ?>" name="<?php echo $this->get_field_name('header_color'); ?>" value="<?php echo $instance['header_color'];?>" />
					</div>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'header_date_color' ); ?>"><?php _e( 'Header Date Color' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['header_date_color']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('header_date_color'); ?>" name="<?php echo $this->get_field_name('header_date_color'); ?>" value="<?php echo $instance['header_date_color'];?>" />
					</div>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'btn_view_background' ); ?>"><?php _e( 'Button View Background' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['btn_view_background']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('btn_view_background'); ?>" name="<?php echo $this->get_field_name('btn_view_background'); ?>" value="<?php echo $instance['btn_view_background'];?>" />
					</div>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'btn_view_background_hover' ); ?>"><?php _e( 'Button View Background Hover' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['btn_view_background_hover']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('btn_view_background_hover'); ?>" name="<?php echo $this->get_field_name('btn_view_background_hover'); ?>" value="<?php echo $instance['btn_view_background_hover'];?>" />
					</div>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'btn_view_color' ); ?>"><?php _e( 'Button View Color' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['btn_view_color']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('btn_view_color'); ?>" name="<?php echo $this->get_field_name('btn_view_color'); ?>" value="<?php echo $instance['btn_view_color'];?>" />
					</div>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'today_background' ); ?>"><?php _e( 'Today Background' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['today_background']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('today_background'); ?>" name="<?php echo $this->get_field_name('today_background'); ?>" value="<?php echo $instance['today_background'];?>" />
					</div>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'event_color_1' ); ?>"><?php _e( 'Event Color 1' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['event_color_1']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('event_color_1'); ?>" name="<?php echo $this->get_field_name('event_color_1'); ?>" value="<?php echo $instance['event_color_1'];?>" />
					</div>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'event_color_2' ); ?>"><?php _e( 'Event Color 2' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['event_color_2']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('event_color_2'); ?>" name="<?php echo $this->get_field_name('event_color_2'); ?>" value="<?php echo $instance['event_color_2'];?>" />
					</div>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'event_color_3' ); ?>"><?php _e( 'Event Color 3' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['event_color_3']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('event_color_3'); ?>" name="<?php echo $this->get_field_name('event_color_3'); ?>" value="<?php echo $instance['event_color_3'];?>" />
					</div>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'event_color_4' ); ?>"><?php _e( 'Event Color 4' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['event_color_4']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('event_color_4'); ?>" name="<?php echo $this->get_field_name('event_color_4'); ?>" value="<?php echo $instance['event_color_4'];?>" />
					</div>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'event_name' ); ?>"><?php _e( 'Event name' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['event_name']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('event_name'); ?>" name="<?php echo $this->get_field_name('event_name'); ?>" value="<?php echo $instance['event_name'];?>" />
					</div>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'event_info' ); ?>"><?php _e( 'Event info' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['event_info']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('event_info'); ?>" name="<?php echo $this->get_field_name('event_info'); ?>" value="<?php echo $instance['event_info'];?>" />
					</div>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'event_desc' ); ?>"><?php _e( 'Event description' ); ?>:</label>
				</td>
				<td>
					<div class="color_for_this" style="background-color: #<?php echo str_replace('#','',$instance['event_desc']);?>">
						<input class="color_input wp-color-picker" id="<?php echo $this->get_field_id('event_desc'); ?>" name="<?php echo $this->get_field_name('event_desc'); ?>" value="<?php echo $instance['event_desc'];?>" />
					</div>
				</td>
			</tr>
		</table>
		
		<hr>
		
		<table style="margin:10px 0 15px 0;">
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'show_image' ); ?>"><?php _e( 'Show Image' ); ?>:</label>
				</td>
				<td>
					<input type="radio" name="<?php echo $this->get_field_name('show_image'); ?>" value="1" <?php if ($instance['show_image'] == "1") echo 'checked="checked"'; ?> /><label for="<?php echo $this->get_field_id( 'show_image' ); ?>1">Yes</label>
					<input type="radio" name="<?php echo $this->get_field_name('show_image'); ?>" value="0" <?php if ($instance['show_image'] == "0") echo 'checked="checked"'; ?> /><label for="<?php echo $this->get_field_id( 'show_image' ); ?>0">No</label>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'show_time' ); ?>"><?php _e( 'Show Time' ); ?>:</label>
				</td>
				<td>
					<input type="radio" name="<?php echo $this->get_field_name('show_time'); ?>" value="1" <?php if ($instance['show_time'] == "1") echo 'checked="checked"'; ?> /><label for="<?php echo $this->get_field_id( 'show_time' ); ?>1">Yes</label>
					<input type="radio" name="<?php echo $this->get_field_name('show_time'); ?>" value="0" <?php if ($instance['show_time'] == "0") echo 'checked="checked"'; ?> /><label for="<?php echo $this->get_field_id( 'show_time' ); ?>0">No</label>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'show_location' ); ?>"><?php _e( 'Show Location' ); ?>:</label>
				</td>
				<td>
					<input type="radio" name="<?php echo $this->get_field_name('show_location'); ?>" value="1" <?php if ($instance['show_location'] == "1") echo 'checked="checked"'; ?> /><label for="<?php echo $this->get_field_id( 'show_location' ); ?>1">Yes</label>
					<input type="radio" name="<?php echo $this->get_field_name('show_location'); ?>" value="0" <?php if ($instance['show_location'] == "0") echo 'checked="checked"'; ?> /><label for="<?php echo $this->get_field_id( 'show_location' ); ?>0">No</label>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'show_description' ); ?>"><?php _e( 'Show Description' ); ?>:</label>
				</td>
				<td>
					<input type="radio" name="<?php echo $this->get_field_name('show_description'); ?>" value="1" <?php if ($instance['show_description'] == "1") echo 'checked="checked"'; ?> /><label for="<?php echo $this->get_field_id( 'show_description' ); ?>1">Yes</label>
					<input type="radio" name="<?php echo $this->get_field_name('show_description'); ?>" value="0" <?php if ($instance['show_description'] == "0") echo 'checked="checked"'; ?> /><label for="<?php echo $this->get_field_id( 'show_description' ); ?>0">No</label>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'show_button' ); ?>"><?php _e( 'Show [View On Facebook]' ); ?>:</label>
				</td>
				<td>
					<input type="radio" name="<?php echo $this->get_field_name('show_button'); ?>" value="1" <?php if ($instance['show_button'] == "1") echo 'checked="checked"'; ?> /><label for="<?php echo $this->get_field_id( 'show_button' ); ?>1">Yes</label>
					<input type="radio" name="<?php echo $this->get_field_name('show_button'); ?>" value="0" <?php if ($instance['show_button'] == "0") echo 'checked="checked"'; ?> /><label for="<?php echo $this->get_field_id( 'show_button' ); ?>0">No</label>
				</td>
			</tr>
			<tr>
				<td width="120px">
					<label for="<?php echo $this->get_field_id( 'show_map' ); ?>"><?php _e( 'Show Map' ); ?>:</label>
				</td>
				<td>
					<input type="radio" name="<?php echo $this->get_field_name('show_map'); ?>" value="1" <?php if ($instance['show_map'] == "1") echo 'checked="checked"'; ?> /><label for="<?php echo $this->get_field_id( 'show_map' ); ?>1">Yes</label>
					<input type="radio" name="<?php echo $this->get_field_name('show_map'); ?>" value="0" <?php if ($instance['show_map'] == "0") echo 'checked="checked"'; ?> /><label for="<?php echo $this->get_field_id( 'show_map' ); ?>0">No</label>
				</td>
			</tr>
		</table>
		
		<hr>
		
        <p>
			<div>
				<label><strong><?php _e( 'Shortcode' ); ?>:</strong></label><br />
				<code>[tiva-facebook-events-calendar page_id="CelebrityTheatre" layout="full"]</code>
			</div>
			<br />
			<div>
				<label><strong><?php _e( 'Other option params:' ); ?>:</strong></label><br />
				<code style="padding:0">
					+ year_range=".." (Default: 1)<br>
					+ header_background="#.." (Default: #5aa4a3)<br>
					+ ...<br>
				</code>
				<label>See detail in document.</label>
			</div>
		</p>
    <?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance                      		 	= array();
		$instance['title']              		= ( ! empty( $new_instance['title'] ) ) ? ( $new_instance['title'] ) : 'Facebook Events Calendar';
		$instance['layout']     	 			= ( ! empty( $new_instance['layout'] ) ) ? ( $new_instance['layout'] ) : 'full';
		$instance['page_id'] 					= ( ! empty( $new_instance['page_id'] ) ) ? ( $new_instance['page_id'] ) : 'CelebrityTheatre';
		$instance['year_range']        			= ( ! empty( $new_instance['year_range'] ) ) ? ( $new_instance['year_range'] ) : '1';
		$instance['initial_view']        		= ( ! empty( $new_instance['initial_view'] ) ) ? ( $new_instance['initial_view'] ) : 'calendar';
		$instance['switch_button']        		= ( ! empty( $new_instance['switch_button'] ) ) ? ( $new_instance['switch_button'] ) : 'show';
		$instance['start_date']        			= ( ! empty( $new_instance['start_date'] ) ) ? ( $new_instance['start_date'] ) : 'sunday';
		$instance['max_events']        			= ( ! empty( $new_instance['max_events'] ) ) ? ( $new_instance['max_events'] ) : '1000';
		$instance['header_background']  		= ( ! empty( $new_instance['header_background'] ) ) ? ( $new_instance['header_background'] ) : '#5aa4a3';
		$instance['header_color']  				= ( ! empty( $new_instance['header_color'] ) ) ? ( $new_instance['header_color'] ) : '#ffffff';
		$instance['header_date_color']  		= ( ! empty( $new_instance['header_date_color'] ) ) ? ( $new_instance['header_date_color'] ) : '#5aa4a3';
		$instance['btn_view_background']  		= ( ! empty( $new_instance['btn_view_background'] ) ) ? ( $new_instance['btn_view_background'] ) : '#757575';
		$instance['btn_view_background_hover']  = ( ! empty( $new_instance['btn_view_background_hover'] ) ) ? ( $new_instance['btn_view_background_hover'] ) : '#5aa4a3';
		$instance['btn_view_color']  			= ( ! empty( $new_instance['btn_view_color'] ) ) ? ( $new_instance['btn_view_color'] ) : '#ffffff';
		$instance['today_background']  			= ( ! empty( $new_instance['today_background'] ) ) ? ( $new_instance['today_background'] ) : '#d5e9e9';
		$instance['event_color_1']  			= ( ! empty( $new_instance['event_color_1'] ) ) ? ( $new_instance['event_color_1'] ) : '#567bd2';
		$instance['event_color_2']  			= ( ! empty( $new_instance['event_color_2'] ) ) ? ( $new_instance['event_color_2'] ) : '#13baff';
		$instance['event_color_3']  			= ( ! empty( $new_instance['event_color_3'] ) ) ? ( $new_instance['event_color_3'] ) : '#669933';
		$instance['event_color_4']  			= ( ! empty( $new_instance['event_color_4'] ) ) ? ( $new_instance['event_color_4'] ) : '#ff8a23';
		$instance['event_name']  				= ( ! empty( $new_instance['event_name'] ) ) ? ( $new_instance['event_name'] ) : '#5aa4a3';
		$instance['event_info']  				= ( ! empty( $new_instance['event_info'] ) ) ? ( $new_instance['event_info'] ) : '#de935f';
		$instance['event_desc']  				= ( ! empty( $new_instance['event_desc'] ) ) ? ( $new_instance['event_desc'] ) : '#666666';
		$instance['show_image']  				= ( ! empty( $new_instance['show_image'] ) ) ? ( $new_instance['show_image'] ) : '0';
		$instance['show_time']  				= ( ! empty( $new_instance['show_time'] ) ) ? ( $new_instance['show_time'] ) : '0';
		$instance['show_location']  			= ( ! empty( $new_instance['show_location'] ) ) ? ( $new_instance['show_location'] ) : '0';
		$instance['show_description']  			= ( ! empty( $new_instance['show_description'] ) ) ? ( $new_instance['show_description'] ) : '0';
		$instance['show_button']  				= ( ! empty( $new_instance['show_button'] ) ) ? ( $new_instance['show_button'] ) : '0';
		$instance['show_map']  					= ( ! empty( $new_instance['show_map'] ) ) ? ( $new_instance['show_map'] ) : '0';
		
		return $instance;
	}
	
	public function widget( $args, $instance ) { 
		if(empty($instance)){
			$instance = array(
				'title' => 'Facebook Events Calendar',
				'layout' => 'full',
				'page_id' => 'CelebrityTheatre',
				'year_range' => '1',
				'initial_view' => 'calendar',
				'switch_button' => 'show',
				'start_date' => 'sunday',
				'max_events' => '1000',
				'header_background' => '#5aa4a3',
				'header_color' => '#ffffff',
				'header_date_color' => '#5aa4a3',
				'btn_view_background' => '#757575',
				'btn_view_background_hover' => '#5aa4a3',
				'btn_view_color' => '#ffffff',
				'today_background' => '#d5e9e9',
				'event_color_1' => '#567bd2',
				'event_color_2' => '#13baff',
				'event_color_3' => '#669933',
				'event_color_4' => '#ff8a23',
				'event_name' => '#5aa4a3',
				'event_info' => '#de935f',
				'event_desc' => '#666666',
				'show_image' 	=> '1',
				'show_time' 	=> '1',
				'show_location' => '1',
				'show_description' => '1',
				'show_button' => '1',
				'show_map' => '1',
			);
		}
		
		$title  					= apply_filters( 'widget_title', $instance['title'] );
		$layout      				= $instance['layout'];
		$page_id 					= $instance['page_id'];
		$year_range 				= $instance['year_range'];
		$initial_view 				= $instance['initial_view'];
		$switch_button 				= $instance['switch_button'];
		$start_date 				= $instance['start_date'];
		$max_events 				= $instance['max_events'];
		$header_background 			= $instance['header_background'];
		$header_color 				= $instance['header_color'];
		$header_date_color 			= $instance['header_date_color'];
		$btn_view_background 		= $instance['btn_view_background'];
		$btn_view_background_hover 	= $instance['btn_view_background_hover'];
		$btn_view_color 			= $instance['btn_view_color'];
		$today_background 			= $instance['today_background'];
		$event_color_1 				= $instance['event_color_1'];
		$event_color_2 				= $instance['event_color_2'];
		$event_color_3 				= $instance['event_color_3'];
		$event_color_4 				= $instance['event_color_4'];
		$event_name 				= $instance['event_name'];
		$event_info 				= $instance['event_info'];
		$event_desc 				= $instance['event_desc'];
		$show_image 				= $instance['show_image'];
		$show_time 					= $instance['show_time'];
		$show_location 				= $instance['show_location'];
		$show_description 			= $instance['show_description'];
		$show_button 				= $instance['show_button'];
		$show_map 					= $instance['show_map'];
		
		// Custom css
		tiva_fb_events_calendar_custom_css('widget', 
										$this->tiva_fb_events_widget, 
										$header_background, 
										$header_color, 
										$header_date_color, 
										$btn_view_background, 
										$btn_view_background_hover,
										$btn_view_color,
										$today_background,
										$event_color_1,
										$event_color_2,
										$event_color_3,
										$event_color_4,
										$event_name,
										$event_info,
										$event_desc
										);
		
		echo $args['before_widget'];
		
		if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}
		
		if ( empty( $page_id ) ) {
			echo "Facebook Page Id is missing in Widget settings.";
		} else {
			?>
			<div class="tiva-events-calendar-wrapper widget-<?php echo $this->tiva_fb_events_widget; ?>">
				<div class="tiva-events-calendar <?php echo $layout; ?>"></div>
				
				<div class="tiva-calendar-param-page hidden-fields"><?php echo $page_id; ?></div>
				<div class="tiva-calendar-param-year hidden-fields"><?php echo $year_range; ?></div>
				<div class="tiva-calendar-param-view hidden-fields"><?php echo $initial_view; ?></div>
				<div class="tiva-calendar-param-switch hidden-fields"><?php echo $switch_button; ?></div>
				<div class="tiva-calendar-param-start hidden-fields"><?php echo $start_date; ?></div>
				<div class="tiva-calendar-param-max hidden-fields"><?php echo $max_events; ?></div>
				<div class="tiva-calendar-param-show-image hidden-fields"><?php echo $show_image; ?></div>
				<div class="tiva-calendar-param-show-time hidden-fields"><?php echo $show_time; ?></div>
				<div class="tiva-calendar-param-show-location hidden-fields"><?php echo $show_location; ?></div>
				<div class="tiva-calendar-param-show-description hidden-fields"><?php echo $show_description; ?></div>
				<div class="tiva-calendar-param-show-button hidden-fields"><?php echo $show_button; ?></div>
				<div class="tiva-calendar-param-show-map hidden-fields"><?php echo $show_map; ?></div>
				
				<div class="tiva-calendar-ajax hidden-fields"><?php echo plugins_url('events.php', __FILE__); ?></div>
				<div class="tiva-calendar-loading hidden-fields"><?php echo plugins_url('assets/images/loading.gif', __FILE__); ?></div>
			</div>
			
			<?php $this->tiva_fb_events_widget++; ?>
		<?php
		}
 
		echo $args['after_widget'];
	}
}

// register widget
function register_tiva_facebook_events_calendar_widget() {
	register_widget( 'TIVA_FACEBOOK_EVENTS_CALENDAR' );
}

add_action( 'widgets_init', 'register_tiva_facebook_events_calendar_widget' );

// Register Shortcode
function tiva_facebook_events_calendar_add_shortcode( $atts ) {
	static $tiva_fb_events_shortcode = 1;
	
	extract(shortcode_atts(
		array(
			'layout' => 'full',
			'page_id' => 'CelebrityTheatre',
			'year_range' => '1',
			'initial_view' => 'calendar',
			'switch_button' => 'show',
			'start_date' => 'sunday',
			'max_events' => '1000',
			'header_background' => '#5aa4a3',
			'header_color' => '#ffffff',
			'header_date_color' => '#5aa4a3',
			'btn_view_background' => '#757575',
			'btn_view_background_hover' => '#5aa4a3',
			'btn_view_color' => '#ffffff',
			'today_background' => '#d5e9e9',
			'event_color_1' => '#567bd2',
			'event_color_2' => '#13baff',
			'event_color_3' => '#669933',
			'event_color_4' => '#ff8a23',
			'event_name' => '#5aa4a3',
			'event_info' => '#de935f',
			'event_desc' => '#666666',
			'show_image' 	=> 'yes',
			'show_time' 	=> 'yes',
			'show_location' => 'yes',
			'show_description' => 'yes',
			'show_button' => 'yes',
			'show_map' => 'yes'
		), $atts )
	);
	
	ob_start();
	
	// Custom css 
	tiva_fb_events_calendar_custom_css('shortcode',
									$tiva_fb_events_shortcode,
									$header_background,
									$header_color,
									$header_date_color,
									$btn_view_background,
									$btn_view_background_hover,
									$btn_view_color,
									$today_background,
									$event_color_1,
									$event_color_2,
									$event_color_3,
									$event_color_4,
									$event_name,
									$event_info,
									$event_desc
									);
	?>
	
	<div class="tiva-events-calendar-wrapper shortcode-<?php echo $tiva_fb_events_shortcode; ?>">
		<div class="tiva-events-calendar <?php echo $layout; ?>"></div>
		
		<div class="tiva-calendar-param-page hidden-fields"><?php echo $page_id; ?></div>
		<div class="tiva-calendar-param-year hidden-fields"><?php echo $year_range; ?></div>
		<div class="tiva-calendar-param-view hidden-fields"><?php echo $initial_view; ?></div>
		<div class="tiva-calendar-param-switch hidden-fields"><?php echo $switch_button; ?></div>
		<div class="tiva-calendar-param-start hidden-fields"><?php echo $start_date; ?></div>
		<div class="tiva-calendar-param-max hidden-fields"><?php echo $max_events; ?></div>
		<div class="tiva-calendar-param-show-image hidden-fields"><?php echo $show_image == 'no' ? 0 : 1; ?></div>
		<div class="tiva-calendar-param-show-time hidden-fields"><?php echo $show_time == 'no' ? 0 : 1; ?></div>
		<div class="tiva-calendar-param-show-location hidden-fields"><?php echo $show_location == 'no' ? 0 : 1; ?></div>
		<div class="tiva-calendar-param-show-description hidden-fields"><?php echo $show_description == 'no' ? 0 : 1; ?></div>
		<div class="tiva-calendar-param-show-button hidden-fields"><?php echo $show_button == 'no' ? 0 : 1; ?></div>
		<div class="tiva-calendar-param-show-map hidden-fields"><?php echo $show_map == 'no' ? 0 : 1; ?></div>
		
		<div class="tiva-calendar-ajax hidden-fields"><?php echo plugins_url('events.php', __FILE__); ?></div>
		<div class="tiva-calendar-loading hidden-fields"><?php echo plugins_url('assets/images/loading.gif', __FILE__); ?></div>
	</div>
	
	<?php
	$html = ob_get_contents();
	ob_end_clean();
	
	return $html;
}

add_shortcode('tiva-facebook-events-calendar', 'tiva_facebook_events_calendar_add_shortcode');